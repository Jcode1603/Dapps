from odoo import models, fields, api, tools
from datetime import timedelta
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_resource_path
import base64

class Website(models.Model):
    _inherit = 'website'

    def _default_bg1(self):
        image_path = get_resource_path('website', 'static/src/img/snippets_demo', 's_cover.jpg')#/website/static/src/img/snippets_demo/s_cover.jpg
        with tools.file_open(image_path, 'rb') as f:
            return base64.b64encode(f.read())
        
    def _default_bg2(self):
        image_path = get_resource_path('website', 'static/src/img/snippets_demo', 's_parallax.jpg')#/website/static/src/img/snippets_demo/s_banner.jpg
        with tools.file_open(image_path, 'rb') as f:
            return base64.b64encode(f.read())

    background1 = fields.Image('First background', default=_default_bg1)
    background2 = fields.Binary('Second background', default=_default_bg2)
    #	http://localhost:2023/web/image/website/1/logo/My%20Website?unique=4a0af2d