from odoo import models, fields, api
from datetime import timedelta
from odoo.exceptions import UserError, ValidationError

class Task(models.Model):
    _inherit = 'project.project'

    type_of_travel = fields.Char(string="Type of Travel")
    trip_style = fields.Char(string="Trip style")
    Number_of_children = fields.Char(string="Number of children")
    Number_of_adults = fields.Char(string="Number of Adults")
    countries_to_visit = fields.Text(string="countries to visit")
    must_haves = fields.Text(string="Must haves")
    exclude = fields.Text(string="Exclude please")
    message = fields.Text(string="Message")
    # name, email amd phone number are filled from contacts module
    duration = fields.Integer(string="Number of Nights")
    check_in_date = fields.Date(string="Check-in Date")
    type_of_lodging = fields.Char(string="Type of Lodging")
    other_services = fields.Char(string="Other services")
    per_person_budget = fields.Float(string="Per person budget")
    country_of_residence = fields.Char(string="Country of residence")
    state = fields.Char(string="State")
    city = fields.Char(string="City")
    include_international_flight = fields.Selection([('yes', 'yes'), ('no', 'no')], string="Include International flight")

    # set defaults for project_id, stage_id, task_properties, display_project_id