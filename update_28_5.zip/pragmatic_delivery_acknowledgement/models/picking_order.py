from odoo import api, models, fields, tools
import string, random
from datetime import datetime
from werkzeug.urls import url_join

class picking_order(models.Model):
    _inherit = "picking.order"

    def _compute_broadcast(self):
        Param = self.env['ir.config_parameter'].sudo()
        if Param.get_param('pragmatic_delivery_control_app.is_broadcast_order'):
            self.broadcast = True
        else:
            self.broadcast = False

    customer_code = fields.Char(string="Customer Acknoledgement Code")
    delivery_boy_code = fields.Char(string="Delivery Boy Acknoledgement Code")
    picking_id = fields.Many2one('stock.picking',string="Deliveryboy Picking")
    is_broadcast_order = fields.Boolean(string="Broadcast Order")
    broadcast = fields.Boolean(string="Broadcast",compute="_compute_broadcast")

    @api.model
    def create(self,vals):
        res = super(picking_order, self).create(vals)
        # ack_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
        Param = self.env['ir.config_parameter'].sudo()
        if Param.get_param('pragmatic_delivery_control_app.is_delivery_acknowledgement'):
            ack_code = ''.join(random.choices(string.digits, k=5))
            res.customer_code = ack_code
            products_list = ""
            for order in res.sale_order.order_line:
                data = "<tr>\
                            <td>%s</td>\
                            <td>%s</td>\
                        </tr>" % (order.product_id.name, order.price_subtotal)
                products_list+=data

            sale_order_link = url_join(self.get_base_url(), "my/orders/%s" % str(res.sale_order.id))
            # if res.sale_order.payment_term_id.name == 'Pay with delivery':
            #     msg = ("<table border='0' cellpadding='0' cellspacing='0' style='padding-top: 16px; background-color: #F1F1F1; font-family:Verdana, Arial,sans-serif; color: #454748; width: 100%; border-collapse:separate;'><tr><td align='center'>\
            #             <table border='0' cellpadding='0' cellspacing='0' width='590' style='padding: 16px; background-color: white; color: #454748; border-collapse:separate;'>\
            #                 <tbody>\
            #                     <tr>\
            #                         <td align='center'' style='min-width: 590px;'>\
            #                             <table border='0' cellpadding='0' cellspacing='0' width='590' style='min-width: 590px; background-color: white; padding: 0px 8px 0px 8px; border-collapse:separate;'>\
            #                                 <tr><td valign='middle'>\
            #                                     <t t-set='company' t-value='object.company_id or object.user_id.company_id or user.company_id'/>\
            #                                     <span style='font-size: 10px;'>Dear Sir / Madam,</span><br/>\
            #                                     <span style='font-size: 20px; font-weight: bold;' t-out="object.name or ''">S00060</span>
            #                                 </td><td valign="middle" align="right">
            #                                     <img t-attf-src="/logo.png?company={{ company.id }}" style="padding: 0px; margin: 0px; height: auto; width: 80px;" t-att-alt="company.name"/>
            #                                 </td></tr>
            #                                 <tr><td colspan="2" style="text-align:center;">
            #                                 <hr width="100%" style="background-color:rgb(204,204,204);border:medium none;clear:both;display:block;font-size:0px;min-height:1px;line-height:0; margin:16px 0px 16px 0px;"/>
            #                                 </td></tr>
            #                             </table>
            #                         </td>
            #                     </tr>
            #            <p> Dear Sir / Madam,</p> \
            #             <p>This is to confirm that we have received your order. We will process and dispatch within 48 hours. </p>\
            #             <p>Otherwise we will reach out to you. Find the details below</p>\
            #             <p> <thead>\
            #                     <tr>\
            #                         <th>Product</th>\
            #                         <th class='text-right'>Price</th>\
            #                     </tr>\
            #                 </thead>\
            #                 <tbody> \
            #                     %s \
            #                 </tbody> \
            #             </p>\
            #             <p>Your Order delivery acknowledge code is %s</p> \
            #            <p>Thank You</p>" % (products_list ,ack_code))
            # else:
            #     msg = ("<p> Dear Sir / Madam,</p> \
            #            <p>This is to confirm that we have received your order. We will process and dispatch within 48 hours. </p> \
            #            <p>Find the details below:</p> \
            #            <p> <thead>\
            #                     <tr>\
            #                         <th>Order ID #</th>\
            #                         <th class='text-right'>Amount Due</th>\
            #                     </tr>\
            #                 </thead>\
            #                 <tbody> \
            #                     %s \
            #                 </tbody> \
            #             </p>\
            #            <p>Your Order delivery acknowledge code is %s</p> \
            #            <p> However, you are required to pay the total sum stated below to the Delivery Agent upon delivery. </p> \
            #            <p>Thank You</p>" % (products_list ,ack_code))
            # msg += "<p> You can track your order by clicking this link: %s</p>" % sale_order_link
            template = self.env['ir.model.data']._xmlid_to_res_id('pragmatic_delivery_acknowledgement.delivery_acknowledgement_email_template')
            rec = self.env['mail.template'].sudo().browse(template)
            if rec:
                # rec.body_html = msg
                rec.send_mail(res.id, force_send=True, raise_exception=True)
        return res

    def assign_driver(self):
        if self.sale_order.id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Assign Delivery Boy',
                'res_model': 'picking.order.wizard',
                'view_type': 'form',
                'view_mode': 'form',
                'context':{'default_sale_order':[(4,self.sale_order.id)]},
                'view_id': self.env.ref('pragmatic_odoo_delivery_boy.assign_driver_wizard', False).id,
                'target': 'new',
            }
        else:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Assign Delivery Boy',
                'res_model': 'picking.order.wizard',
                'view_type': 'form',
                'view_mode': 'form',
                'context':{'default_pos_order_ids':[(4,self.pos_order_id.id)]},
                'view_id': self.env.ref('pragmatic_odoo_delivery_boy.assign_driver_wizard', False).id,
                'target': 'new',
            }

    def pick_delivery(self):
        """
        this process happen after the delivery of order completed by delivery boy from the website.
        it is make done picking if 'Enable Delivery Boy Location' is not enable
        it is create a new picking for delivery boy and make transfer like
            store location -> delivery boy location
            delivery boy location -> customer
        """
        # delivery_boy_store_configuration = self.user_has_groups('pragmatic_delivery_control_app.group_delivery_boy_store_configuration')
        picking = self.picking
        picking.action_assign()
        print("\n \n:::picking::", picking)
        # if not delivery_boy_store_configuration:
        #     if self.picking.state == 'assigned':
        #         for move in picking.move_lines.filtered(lambda m: m.state not in ['done', 'cancel']):
        #             for move_line in move.move_line_ids:
        #                 move_line.qty_done = move_line.product_uom_qty
        #         picking.with_context(skip_immediate=True).button_validate()
        # else:
        picking_type_obj = self.env['stock.picking.type']
        delivery_boy_location = self.env['delivery.boy.store'].search([('delivery_boy_id.partner_id','=',self.delivery_boy.id)])
        deliveryboy_picking_id = picking.copy()
        print("\n \n:deliveryboy_picking_id", deliveryboy_picking_id)
        picking_type_id = picking_type_obj.search([('sequence_code', '=', 'TDB')])
        deliveryboy_picking_id.picking_type_id = picking_type_id.id
        deliveryboy_picking_id.action_assign()
        deliveryboy_picking_id.location_dest_id = delivery_boy_location.location_id.id
        for move in deliveryboy_picking_id.move_lines.filtered(lambda m: m.state not in ['done', 'cancel']):
            for move_line in move.move_line_ids:
                move_line.qty_done = move_line.product_uom_qty
                move_line.location_dest_id = delivery_boy_location.location_id.id
        deliveryboy_picking_id.with_context(skip_immediate=True).button_validate()
        # self.sale_order.write({'state':'picked'})
        self.picking_id = deliveryboy_picking_id.id

        picking.location_id = deliveryboy_picking_id.location_dest_id
        for move in picking.move_lines.filtered(lambda m: m.state not in ['done', 'cancel']):
            for move_line in move.move_line_ids:
                move_line.location_id = deliveryboy_picking_id.location_dest_id
                move_line.qty_done = move_line.product_uom_qty
        picking.with_context(skip_immediate=True).button_validate()
        self.state = 'picked'
        order_stage_id = self.env['order.stage'].search([('action_type', '=', 'picked')])
        if order_stage_id:
            self.stage_id = order_stage_id.id

        """
            reconsile invoice
        """

        move_obj = self.env['account.move'].sudo()
        if self.sale_order:
            invoice_id = self.sale_order.invoice_ids
        elif self.pos_order_id:
            invoice_id = self.pos_order_id.account_move
            print("\n \n:::invoic_id:::::::;elif", invoice_id)
            # move_id = self.pos_order_id.action_pos_order_invoice()
            # invoice_id = self.env['account.move'].browse(move_id.get('res_id'))
        print("\n \n::invoice_id:::::", invoice_id)
        store_config_id = self.env['store.configuration'].sudo().search(
            [('location_id', '=', self.picking.location_id.id)])
        if store_config_id and invoice_id:
            line_ids = [(0, 0, {
                'partner_id': self.delivery_boy.id,  # delivery boy id,
                'account_id': store_config_id.delivery_boy_account_id.id,
                'journal_id': store_config_id.delivery_boy_journal_id.id,
                'name': 'Cash received by delivery boy from order Number {0}'.format(self.sale_order.name),
                'amount_currency': 0.0,
                'debit': invoice_id.amount_total,
                'credit': 0.0,
            }),
                        (0, 0, {
                            'partner_id': invoice_id.partner_id.id,
                            'account_id': invoice_id.partner_id.property_account_receivable_id.id,
                            'journal_id': store_config_id.delivery_boy_journal_id.id,
                            'name': 'Cash received by delivery boy from order Number {0}'.format(self.sale_order.name),
                            'amount_currency': 0.0,
                            'debit': 0.0,
                            'credit': invoice_id.amount_total,
                        })]

            vals = {
                'journal_id': store_config_id.delivery_boy_journal_id.id,
                'ref': 'Cash received by delivery boy from order Number {0}'.format(self.sale_order.name),
                'narration': 'Delivery Boy Receipt',
                'date': datetime.now(),
                'line_ids': line_ids,
            }
            journal_id = move_obj.create(vals)
            journal_id.sudo().action_post()
            self.delivery_boy_move_id = journal_id.id

            line_1 = journal_id.line_ids.filtered(lambda line: line.account_id.user_type_id.type == 'receivable')
            line_2 = invoice_id.line_ids.filtered(lambda line: (line.account_id.user_type_id.type == 'receivable'))
            (line_1 + line_2).reconcile()

        if invoice_id:
            self.action_picking_order_paid(invoice_id.id)

        """
            create invoice for order
        """
        print("\n \n:invoice_id::;", invoice_id)
        if not self.sale_order.invoice_count and not self.pos_order_id:
            invoice_obj = self.sale_order._create_invoices()
            invoice_obj.action_post()
            self.invoice = invoice_obj.id
        elif self.pos_order_id:
            move_id = self.pos_order_id.action_pos_order_invoice()
            invoice_obj = self.env['account.move'].browse(move_id.get('res_id'))
            self.invoice = invoice_obj.id
            # delivery_charge_config_id = self.env['res.config.settings'].search([('delivery_charge', '=', True)])
            # Param = self.env['res.config.settings'].sudo().get_values()
            # delivery_charge_config_id = Param.get('delivery_charge')
            # print("\n \n:delivery_charge_config_id:;", delivery_charge_config_id, self.delivery_boy.drive_rate)
            # if delivery_charge_config_id and self.delivery_boy.drive_rate > 0:
            #     print("\n \n:self.invoice.payment_state::", self.invoice.payment_state)
            #     if self.invoice.payment_state == 'not_paid':
            #         delivery_line = {
            #             'product_id': self.env.ref('pragmatic_odoo_delivery_boy.product_delivery_charge').id,
            #             'quantity': 1.0,
            #             'price_unit': self.delivery_boy.drive_rate * self.distance_btn_2_loc,
            #             'account_id': invoice_id.partner_id.property_account_receivable_id.id,
            #             'move_id': self.invoice.id,
            #             'credit': self.delivery_boy.drive_rate * self.distance_btn_2_loc,
            #             'debit': abs(self.delivery_boy.drive_rate * self.distance_btn_2_loc),
            #         }
            #         self.invoice.write({'invoice_line_ids': [(0, 0, delivery_line)]})
            #     elif self.invoice.payment_state == 'paid':
            #         self.invoice.button_draft()
            #         delivery_line = {
            #             'product_id': self.env.ref('pragmatic_odoo_delivery_boy.product_delivery_charge').id,
            #             'quantity': 1.0,
            #             'price_unit': self.delivery_boy.drive_rate * self.distance_btn_2_loc,
            #             'account_id': invoice_id.partner_id.property_account_receivable_id.id,
            #             'move_id': self.invoice.id,
            #             'credit': self.delivery_boy.drive_rate * self.distance_btn_2_loc,
            #             'debit': abs(self.delivery_boy.drive_rate * self.distance_btn_2_loc),
            #         }
            #         self.invoice.write({'invoice_line_ids': [(0, 0, delivery_line)]})
            #         bank_journal_id = self.env['account.journal'].search([('type', '=', 'bank')], limit=1)
            #         cash_journal_id = self.env['account.journal'].search([('type', '=', 'cash')], limit=1)
            #         payment_method_id = self.env['account.payment.method'].search([('payment_type', '=', 'inbound')], limit=1)
            #         payment = self.env['account.payment.register']\
            #         .with_context(active_model='account.move', active_ids=self.invoice.ids)\
            #         .create({
            #             'payment_date': self.invoice.invoice_date,
            #             'amount': self.invoice.amount_residual,
            #             'journal_id': bank_journal_id.id,
            #         })\
            #         ._create_payments()

    # def pick_delivery(self):
    #     """
    #     this process happen after the delivery of order completed by delivery boy from the website.
    #     it is make done picking if 'Enable Delivery Boy Location' is not enable
    #     it is create a new picking for delivery boy and make transfer like
    #         store location -> delivery boy location
    #         delivery boy location -> customer
    #     """
    #     # delivery_boy_store_configuration = self.user_has_groups('pragmatic_delivery_control_app.group_delivery_boy_store_configuration')
    #     picking = self.picking
    #     picking.action_assign()
    #     # if not delivery_boy_store_configuration:
    #     #     if self.picking.state == 'assigned':
    #     #         for move in picking.move_lines.filtered(lambda m: m.state not in ['done', 'cancel']):
    #     #             for move_line in move.move_line_ids:
    #     #                 move_line.qty_done = move_line.product_uom_qty
    #     #         picking.with_context(skip_immediate=True).button_validate()
    #     # else:
    #     picking_type_obj = self.env['stock.picking.type']
    #     delivery_boy_location = self.env['delivery.boy.store'].search([('delivery_boy_id.partner_id','=',self.delivery_boy.id)])
    #     deliveryboy_picking_id = picking.copy()
    #     picking_type_id = picking_type_obj.search([('sequence_code', '=', 'TDB')])
    #     deliveryboy_picking_id.picking_type_id = picking_type_id.id
    #     deliveryboy_picking_id.action_assign()
    #     deliveryboy_picking_id.location_dest_id = delivery_boy_location.location_id.id
    #     for move in deliveryboy_picking_id.move_lines.filtered(lambda m: m.state not in ['done', 'cancel']):
    #         for move_line in move.move_line_ids:
    #             move_line.qty_done = move_line.product_uom_qty
    #             move_line.location_dest_id = delivery_boy_location.location_id.id
    #     deliveryboy_picking_id.with_context(skip_immediate=True).button_validate()
    #     # self.sale_order.write({'state':'picked'})
    #     self.picking_id = deliveryboy_picking_id.id

    #     picking.location_id = deliveryboy_picking_id.location_dest_id
    #     for move in picking.move_lines.filtered(lambda m: m.state not in ['done', 'cancel']):
    #         for move_line in move.move_line_ids:
    #             move_line.location_id = deliveryboy_picking_id.location_dest_id
    #             move_line.qty_done = move_line.product_uom_qty
    #     picking.with_context(skip_immediate=True).button_validate()
    #     self.state = 'picked'
    #     order_stage_id = self.env['order.stage'].search([('action_type', '=', 'picked')])
    #     if order_stage_id:
    #         self.stage_id = order_stage_id.id

    #     """
    #         reconsile invoice
    #     """

    #     move_obj = self.env['account.move'].sudo()
    #     invoice_id = self.sale_order.invoice_ids
    #     store_config_id = self.env['store.configuration'].sudo().search(
    #         [('location_id', '=', self.picking.location_id.id)])
    #     if store_config_id and invoice_id:
    #         line_ids = [(0, 0, {
    #             'partner_id': self.delivery_boy.id,  # delivery boy id,
    #             'account_id': store_config_id.delivery_boy_account_id.id,
    #             'journal_id': store_config_id.delivery_boy_journal_id.id,
    #             'name': 'Cash received by delivery boy from order Number {0}'.format(self.sale_order.name),
    #             'amount_currency': 0.0,
    #             'debit': invoice_id.amount_total,
    #             'credit': 0.0,
    #         }),
    #                     (0, 0, {
    #                         'partner_id': invoice_id.partner_id.id,
    #                         'account_id': invoice_id.partner_id.property_account_receivable_id.id,
    #                         'journal_id': store_config_id.delivery_boy_journal_id.id,
    #                         'name': 'Cash received by delivery boy from order Number {0}'.format(self.sale_order.name),
    #                         'amount_currency': 0.0,
    #                         'debit': 0.0,
    #                         'credit': invoice_id.amount_total,
    #                     })]

    #         vals = {
    #             'journal_id': store_config_id.delivery_boy_journal_id.id,
    #             'ref': 'Cash received by delivery boy from order Number {0}'.format(self.sale_order.name),
    #             'narration': 'Delivery Boy Receipt',
    #             'date': datetime.now(),
    #             'line_ids': line_ids,
    #         }
    #         journal_id = move_obj.create(vals)
    #         journal_id.sudo().action_post()
    #         self.delivery_boy_move_id = journal_id.id

    #         line_1 = journal_id.line_ids.filtered(lambda line: line.account_id.user_type_id.type == 'receivable')
    #         line_2 = invoice_id.line_ids.filtered(lambda line: (line.account_id.user_type_id.type == 'receivable'))
    #         (line_1 + line_2).reconcile()

    #     if invoice_id:
    #         self.action_picking_order_paid(invoice_id.id)

    #     """
    #         create invoice for order
    #     """
    #     if not self.sale_order.invoice_count:
    #         invoice_obj = self.sale_order._create_invoices()
    #         invoice_obj.action_post()
    #         self.invoice = invoice_obj.id

    def print_invoice(self):
        self.ensure_one()
        if self.sale_order.invoice_ids:
            action = self.sale_order.invoice_ids.action_invoice_print()
            # action.update({'close_on_report_download': True})
            return action
        elif self.pos_order_id.account_move:
            action = self.pos_order_id.account_move.action_invoice_print()
            # action.update({'close_on_report_download': True})
            return action

    def check_deliveryboy_code(self,deliveryboy_code):
        if self.customer_code == deliveryboy_code:
            self.delivery_boy_code = deliveryboy_code
            return True
        else:
            return False

    def delivery_order_ready(self):
        self.is_broadcast_order = True
