from odoo import fields, api, models, _
from datetime import datetime, timedelta
import logging
_logger = logging.getLogger(__name__)

class DriverTracking(models.Model):
    _name = 'driver.tracking'
    _inherit = 'mail.thread'
    _description = "Tracking records of an driver"
    _order = "id desc"
    _rec_name="driver_id"

    def _default_driver(self):
        return self.env['res.partner'].search([('user_id', '=', self.env.uid)], limit=1)

    active = fields.Boolean('Active', default=True)
    driver_id = fields.Many2one('res.partner', string="Driver", default=_default_driver, required=True)
    action_date = fields.Datetime('Date Time',default=fields.Datetime.now)
    lat_lng = fields.Char('Lat,Long')
    latitude = fields.Char('Latitude')
    longitude = fields.Char('Longitude')
    time_stamp_type = fields.Selection([
        ('check_in', 'Check In'),
        ('check_out', 'Check Out'),
        ('start', 'Start Journey'),
        ('reached', 'Reached'),
        ('leave', 'Leave'),
        ('trip_process', 'Trip Progress'),
        ('without_task', 'Without Task')
    ], required=True, default='check_in')
    company_id = fields.Many2one(
        'res.company', string='Company', index=True, compute='_compute_company')
    fieldLat = fields.Float(compute='_compute_company')
    fieldLng = fields.Float(compute='_compute_company')
    attachment_count = fields.Integer('Attacment Count', compute='_compute_attachment_count')

    def _compute_company(self):
        for rec in self:
            rec.company_id = self.env.user.company_id
            rec.fieldLat = rec.company_id.partner_id.partner_latitude
            rec.fieldLng = rec.company_id.partner_id.partner_longitude

    def _compute_attachment_count(self):
        for rec in self:
            x=0
            count = self.env['ir.attachment'].search([('res_model','=','driver.tracking'),('res_id','=',rec.id)])
            _logger.info("COUNT============>>>>>>>>>>>>>>>%s",len(count))
            
            rec.attachment_count = len(count)