from odoo import api, models, fields, tools, _


class AssignDriverWizard(models.TransientModel):
    _name = 'assign.driver.wizard'
    _description = 'Assign delivery boy'

    delivery_boy = fields.Many2one('res.partner', 'Delivery Boy',
                                   domain="[('is_driver', '=', True),('status','=','available')]")

    def assign_driver(self):
        active_id = self._context.get('active_ids')
        picking_orders = self.env['picking.order'].browse(active_id)
        for picking_order in picking_orders:
            picking_order.write({'delivery_boy':self.delivery_boy.id})
