odoo.define('website_sale_options.website_sale_zone', function (require) {
'use strict';

    const core = require('web.core');
    var ajax = require('web.ajax');

    var _t = core._t;
    require('web.dom_ready');
    var publicWidget = require('web.public.widget');

    publicWidget.registry.ModalExample = publicWidget.Widget.extend({
    selector: '.checkout_autoformat',
        xmlDependencies: [],
        disabledInEditableMode: false,
        events: {
         'change .zone_id': '_onChangeZone',
        },

        _onChangeZone: function(ev){
               var $target = $(ev.currentTarget)
               if ($target.val()){
                    this._rpc({
                    route: "/shop/order/update_zone",
                    params: {
                        'zone_id':$("#zone_id").val(),
                    },
                    }).then(function (data) {
                        console.log("data-------------- ",data)
                        window.location.reload()
                    });
               }
        }

    })

    var jQueryScript = document.createElement('script');
    ajax.jsonRpc('/get_google_api_key', 'call')
            .then(function (data) {
                // console.log("Google api key : ",data)
                jQueryScript.setAttribute('src','https://maps.googleapis.com/maps/api/js?key='+ data +'&amp;region=SA&amp;libraries=places');
                document.head.appendChild(jQueryScript);
            })

    $(document).ready(function() {

        let map;
        let marker;

        function initMap(order_id) {

            ajax.jsonRpc('/get_source_dest_location', 'call', {'order_id':order_id,})
            .then(function (data) {
                console.log("Result :=================== ",data)

                if(data){
                    if (data.result == true){

                        const directionsService = new google.maps.DirectionsService();
                        const directionsRenderer = new google.maps.DirectionsRenderer();

                        map = new google.maps.Map(document.getElementById("map_canvas"), {
                            center: { lat: -34.397, lng: 150.644 },
                            zoom: 8,
                        });

                        directionsRenderer.setMap(map);


                        var source_latlng = new google.maps.LatLng(data.source_loc[0], data.source_loc[1]);
                        var dest_latlng = new google.maps.LatLng(data.dest_loc[0], data.dest_loc[1]);

                        const icon = {
                            url: "/pragmatic_odoo_delivery_boy/static/description/img/delivery_boy.png",
                            size: new google.maps.Size(71, 71),
                            origin: new google.maps.Point(0, 0),
                            anchor: new google.maps.Point(17, 34),
                            scaledSize: new google.maps.Size(35, 35),
                        };


                        marker = new google.maps.Marker({
                            position: source_latlng,
                            map: map,
                            icon:icon,
                            draggable: false
                        });

                        directionsService
                        .route({
                          origin: source_latlng,
                          destination: dest_latlng,
                          travelMode: google.maps.TravelMode.DRIVING,
                        })
                        .then((response,status) => {
                          directionsRenderer.setDirections(response);
                        })
                        .catch((e) => window.alert("Directions request failed due to " + status));
                    }
                    if (data.result == false){
                        alert(data.message)
                    }
                }
            })
        }

        $('#trackOrderModel').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var self = this
                setTimeout(function(){
                    initMap(button.data('order_id'));
                    $("#location-map").css("width", "100%");
                    $("#map_canvas").css("width", "100%");
                    $('#location-map').attr('data-order_id',button.data('order_id'));

                },1000)
        })

        setInterval(function(){
            if(($("#trackOrderModel").data('bs.modal') || {})._isShown){
                var order_id = $('#location-map').attr('data-order_id')
                console.log("modal open and order id : ",order_id)
                ajax.jsonRpc('/get_driver_live_location', 'call', {'order_id':order_id,})
                .then(function (data) {
                        console.log("dataaaaaaaaaaaa : ",data)
                      moveMarkerMap(data);

//                    var myLatlng = new google.maps.LatLng(data.lat, data.lng);
//                    var marker = new google.maps.Marker({
//                        position: myLatlng,
//                    });
//                    marker.setMap(map);
                })

                function moveMarkerMap(newCoords) {
                    var newLatLang = new google.maps.LatLng(newCoords.lat, newCoords.lng);
                    map.panTo(newLatLang);
                    marker.setPosition(newLatLang);

                }
           }
        },30000)

    }); //ready

});//main