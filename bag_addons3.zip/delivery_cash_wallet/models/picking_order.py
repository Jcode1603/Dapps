from odoo import api, models, fields, tools, _
from odoo.exceptions import UserError
import googlemaps


class picking_order(models.Model):
    _inherit = "picking.order"

    order_details = fields.Char('Order')
    delivery_boy_move_id = fields.Many2one('account.move',string="Delivery Boy Journal Ref")
    order_amount = fields.Float(string="Total")
    payment_term_id = fields.Many2one('account.payment.term',string="Payment Term")
    date_order = fields.Datetime(string="Order Date")

    def create(self,vals):
        sale_order_id = self.env['sale.order'].browse(vals.get('sale_order'))
        # self.update({'order_amount': sale_order_id.amount_total, 'payment_term_id': sale_order_id.payment_term_id,
        #     'date_order': sale_order_id.date_order, 'order_details': sale_order_id.name})
        google_api_key = self.env['ir.config_parameter'].sudo().get_param('google.api_key_geocode')
        gmaps = googlemaps.Client(key=google_api_key)
        partner_id = self.env['res.partner'].sudo().browse(vals.get('partner_id'))
        warehouse_id = self.env['stock.warehouse'].sudo().browse(vals.get('warehouse_id'))
        if partner_id.parent_id:
            partner_id.country_id = partner_id.parent_id.country_id.id
            partner_id.partner_latitude = partner_id.parent_id.partner_latitude
            partner_id.partner_longitude = partner_id.parent_id.partner_longitude
            partner_id.zone_configuration_id = partner_id.parent_id.zone_configuration_id.id
            source = (warehouse_id.partner_id.partner_latitude, warehouse_id.partner_id.partner_longitude)
            destination = (partner_id.partner_latitude, partner_id.partner_longitude)
            distance = gmaps.distance_matrix(source, destination)["rows"][0]["elements"][0]["distance"]
            distance_btn_2_loc = distance['value'] * 0.002
            # distance_btn_2_loc = 10.002
            vals.update({'distance_btn_2_loc': distance_btn_2_loc})
            partner_id.calculate_distance = distance_btn_2_loc
            partner_id.parent_id.calculate_distance = distance_btn_2_loc
        else:
            if partner_id.partner_latitude and partner_id.partner_longitude and warehouse_id.partner_id.partner_latitude and warehouse_id.partner_id.partner_longitude:
                source = (warehouse_id.partner_id.partner_latitude, warehouse_id.partner_id.partner_longitude)
                destination = (partner_id.partner_latitude, partner_id.partner_longitude)
                distance = gmaps.distance_matrix(source, destination)["rows"][0]["elements"][0]["distance"]
                distance_btn_2_loc = distance['value'] * 0.002
                # distance_btn_2_loc = 10.002
                vals.update({'distance_btn_2_loc': distance_btn_2_loc})
                partner_id.calculate_distance = distance_btn_2_loc

        return super(picking_order, self).create(vals)
        # res.order_amount = res.sale_order.amount_total
        # res.payment_term_id = res.sale_order.payment_term_id
        # print("\n \n::res.sale_order.date_order:", res.sale_order.date_order)
        # res.date_order = res.sale_order.date_order
        # return res

    def write(self, vals):
        if vals.get('pos_order_id'):
            pos_order_id = self.env['pos.order'].browse(vals.get('pos_order_id'))
            self.write({'order_amount': pos_order_id.amount_total, 'date_order': pos_order_id.date_order, 'order_details': pos_order_id.pos_reference})
        res = super(picking_order, self).write(vals)
        return res

    def invoice_register_payment(self):
        account_journal = self.env['account.journal'].sudo().search([('name', '=', 'Bank')],limit=1)
        payment_method = self.env['account.payment.method'].sudo().search([])
        for rec in self:
            if rec.invoice and rec.state == "delivered":
                invoice_id = rec.invoice
                vals={
                    'payment_type': 'inbound',
                    'partner_type': 'customer',
                    'partner_id': invoice_id.partner_id.id,
                    'ref': invoice_id.name,
                    'amount': invoice_id.amount_total,
                    'payment_method_id': payment_method[0].id,
                    'journal_id': account_journal.id,
                }
                payment = self.env['account.payment'].sudo().create(vals)
                if payment:
                    payment.action_post()
                    rec.state = "payment_collected"

                to_reconcile = []

                available_lines = self.env['account.move.line']
                for line in invoice_id.line_ids:
                    if line.move_id.state != 'posted':
                        raise UserError(_("You can only register payment for posted journal entries."))

                    if line.account_internal_type not in ('receivable', 'payable'):
                        continue
                    if line.currency_id:
                        if line.currency_id.is_zero(line.amount_residual_currency):
                            continue
                    else:
                        if line.company_currency_id.is_zero(line.amount_residual):
                            continue
                    available_lines |= line

                to_reconcile.append(available_lines)
                domain = [('account_internal_type', 'in', ('receivable', 'payable')), ('reconciled', '=', False)]

                for payment, lines in zip(payment, to_reconcile):
                    if payment.state != 'posted':
                        continue
                    payment_lines = payment.line_ids.filtered_domain(domain)
                    for account in payment_lines.account_id:
                        (payment_lines + lines) \
                            .filtered_domain([('account_id', '=', account.id), ('reconciled', '=', False)]) \
                            .reconcile()
            else:
                raise UserError(_("You can only register payment for 'Delivered' Order"))
