import base64
import json
import logging

from odoo import http
from odoo.http import content_disposition, request, _logger, Response
import datetime

class AttachmentController(http.Controller):

    @http.route(['/attachment/upload'], type='http', auth="none", methods=['POST'], csrf=False)
    def test(self, **post):
        _logger.info('CONNECTION SUCCESSFUL!!')
        _logger.info(post)
        response = {'response': "ok", 'status': 200}
        if post.get('name') and post.get('res_id') and post.get('res_model') and post.get('type'):
            picking_order=request.env[post.get('res_model')].sudo().search([('id','=',post.get('res_id'))])
            res = request.env['ir.attachment'].sudo().create(post)
            if picking_order and res:
                image_type = post.get('name').split('_',1)[1]
                if image_type == 'delivery_image':
                    picking_order.write({'is_delivery_image':True})
                if image_type == 'delivery_signature':
                    picking_order.write({'is_signature': True})
            response.update({'response': "ok", 'status': 200, 'res': res.id})
        else:
            response.update({'response': 'Bad request', 'status': 400})
            return json.dumps(response)
        return json.dumps(response)
