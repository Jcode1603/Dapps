from odoo import api, models, fields, tools, _
from odoo.exceptions import UserError
import googlemaps

class picking_order(models.Model):
    _inherit = "picking.order"

    partner_invoice_id = fields.Many2one("res.partner",string="Invoice Address")
    partner_shipping_id = fields.Many2one("res.partner",string="Shipping Address")

    def create(self,vals):
        res = super(picking_order, self).create(vals)
        if res.sale_order:
            res.partner_invoice_id = res.sale_order.partner_invoice_id
            res.partner_shipping_id = res.sale_order.partner_shipping_id
        return res
