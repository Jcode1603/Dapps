odoo.define('home_delivery_odoo_pos_website_mobile_pragtech.HomeDeliveryButton', function(require) {
    'use strict';

    const { useListener } = require('web.custom_hooks');
    const PosComponent = require('point_of_sale.PosComponent');
    const ProductScreen = require('point_of_sale.ProductScreen');
    const Registries = require('point_of_sale.Registries');
    var rpc = require('web.rpc');

    class HomeDeliveryButton extends PosComponent {
        constructor() {
            super(...arguments);
            useListener('click', this.onClick);
        }
        async _createHomeDeliveryOrder(values) {
            try {
                const result = await this.rpc({
                    route: '/create/homedelivery',
                    params: values,
                });
                var order    = this.env.pos.get_order();
                var lines    = order.get_orderlines();
                if (values.delivery_person){
                    const domain = [['id', '=', values.delivery_person]];
                    const fields = ['drive_rate'];
                    const partners = await this.rpc({
                        args: [domain, fields],
                        method: 'search_read',
                        model: 'res.partner',
                    });
                    const partner_domain = [['id', '=', values.partner_id]];
                    const partner_fields = ['calculate_distance', 'zone_configuration_id'];
                    const partner_id = await this.rpc({
                        args: [partner_domain, partner_fields],
                        method: 'search_read',
                        model: 'res.partner',
                    });
                    
                    if (partner_id){
                        var product  = this.env.pos.db.get_product_by_id(this.env.pos.config.delivery_charge_product_id[0]);
                        var zone_product = this.env.pos.db.get_product_by_id(this.env.pos.config.zone_charge_product_id[0]);
                        if (product){
                            var delivery_charge_amount = this.env.pos.config.delivery_charge_amount;
                            order.add_product(product, {
                                price: partners[0].drive_rate*partner_id[0].calculate_distance,
                                lst_price: partners[0].drive_rate*partner_id[0].calculate_distance,
                                extras: {
                                    price_manually_set: true,
                                },
                            });
                        }
                        if (zone_product && partner_id[0].zone_configuration_id){
                            const zone_domain = [['id', '=', partner_id[0].zone_configuration_id[0]]];
                            const zone_fields = ['zone_price'];
                            const zone_id = await this.rpc({
                                args: [zone_domain, zone_fields],
                                method: 'search_read',
                                model: 'zone.configuration',
                            });
                            // var delivery_charge_amount = this.env.pos.config.delivery_charge_amount;
                            order.add_product(zone_product, {
                                price: zone_id[0].zone_price,
                                lst_price: zone_id[0].zone_price,
                                extras: {
                                    price_manually_set: true,
                                },
                            });
                        }
                    }
                }
                if (!values.delivery_person){
                    const partner_domain = [['id', '=', values.partner_id]];
                    const partner_fields = ['calculate_distance', 'zone_configuration_id'];
                    const partner_id = await this.rpc({
                        args: [partner_domain, partner_fields],
                        method: 'search_read',
                        model: 'res.partner',
                    });
                    if (partner_id){
                        var product  = this.env.pos.db.get_product_by_id(this.env.pos.config.delivery_charge_product_id[0]);
                        var zone_product = this.env.pos.db.get_product_by_id(this.env.pos.config.zone_charge_product_id[0]);
                        if (product){
                            var delivery_charge_amount = this.env.pos.config.delivery_charge_amount;
                            order.add_product(product, {
                                price: delivery_charge_amount*partner_id[0].calculate_distance,
                                lst_price: delivery_charge_amount*partner_id[0].calculate_distance,
                                extras: {
                                    price_manually_set: true,
                                },
                            });
                        }
                        if (zone_product){
                            const zone_domain = [['id', '=', partner_id[0].zone_configuration_id[0]]];
                            const zone_fields = ['zone_price'];
                            const zone_id = await this.rpc({
                                args: [zone_domain, zone_fields],
                                method: 'search_read',
                                model: 'zone.configuration',
                            });
                            // var delivery_charge_amount = this.env.pos.config.delivery_charge_amount;
                            order.add_product(zone_product, {
                                price: zone_id[0].zone_price,
                                lst_price: zone_id[0].zone_price,
                                extras: {
                                    price_manually_set: true,
                                },
                            });
                        }
                    }
                }
                let msg = "";
                if(result == "already created") {
                    msg = "Delivery Order already exists/created!";
                } else if(result) {
                    msg = "Delivery Order created successfully!";
                } else {
                    msg = "Something went wrong, Try again!";
                }
                await this.showPopup('ConfirmPopup', {
                    title: this.env._t('Home Delivery'),
                    body: this.env._t(msg),
                });
            } catch (error) {
                if (error.message.code < 0) {
                    await this.showPopup('OfflineErrorPopup', {
                        title: this.env._t('Offline'),
                        body: this.env._t('Unable to create home delivery order, please try after some time.'),
                    });
                } else {
                    throw error;
                }
            }
        }
        async createHomeDeliveryOrder(payload) {
            //write your side effect here!!!!
            const order = this.env.pos.get_order();
            const selected_customer = order.get_client();
            order.set_delivery_type("home_delivery");
            order.set_delivery_type_name("Home Delivery");
            const orderlines = order.get_orderlines();
            let products = [];
            orderlines.map(line => {
                let product = {
                    "id": line.product.id,
                    "categ_id": line.product.categ_id,
                    "list_price": line.product.list_price,
                    "lst_price": line.product.lst_price,
                    "standard_price": line.product.standard_price,
                    "product_tmpl_id": line.product.product_tmpl_id,
                    "display_name": line.product.display_name,
                    "uom_id": line.product.uom_id,
                    "qty": line.get_quantity(),
                    "price_unit": line.get_unit_price(),
                };
                products.push(product);
            });
//            console.log("this.env.pos.pos_session: ",this.env.pos.pos_session)
//            console.log("this.env.pos.pos_session.config_id: ",this.env.pos.pos_session.config_id)
//            console.log("this.env.pos.pos_session.config_id.picking_type_id: ",this.env.pos.pos_session.config_id.picking_type_id)
//            console.log("this.env.pos.pos_session.config_id.picking_type_id.warehouse_id: ",this.env.pos.pos_session.config_id.picking_type_id.warehouse_id)
//            console.log("this.env.pos.pos_session.config_id.picking_type_id.warehouse_id.id: ",this.env.pos.pos_session.config_id.picking_type_id.warehouse_id.id)

            let create_delivery = {
                "partner_id": selected_customer.id,
                "name": order.name,
                "product_lst": products,
                "session_id": this.env.pos.pos_session.id,
//                "warehouse_id": this.env.pos.pos_session.config_id.picking_type_id.warehouse_id.id,
                "cashier": this.env.pos.get_cashier().user_id[0],
                "delivery_type": "home_delivery",
                "delivery_person": parseInt(payload.deliveryPerson),
                "delivery_time": payload.custDeliveryTime,
                "display_delivery_time": payload.custDeliveryTime,
                "order_note": payload.custDeliveryNote,
                "customer_name": payload.custName,
                "phone": payload.custMobile,
                "email": payload.custEmail,
                "street": payload.custLocality,
                "street2": payload.custStreet,
                "city": payload.custCity,
                "zip": payload.custZip,
                "ship_to_diff_addr": payload.custName ? true : false,
            };
            const delivery_person = this.env.pos.users_lst.filter(user => user.id == payload.deliveryPerson);
            this.env.pos.delivery_person_name = delivery_person && delivery_person.name || "";
            this._createHomeDeliveryOrder(create_delivery);
            create_delivery.delivery_time = moment(create_delivery.delivery_time).format('MMMM Do YYYY, hh mm a');
            console.log("\n \n::create_delivery::", create_delivery)
            this.env.pos.delivery_details = create_delivery;
        }
        async onClick() {
            const order = this.env.pos.get_order();
            if(order) {
                if(order && !order.get_client()) {
                    await this.showPopup('ErrorPopup', {
                        title: 'Customer?',
                        body: 'First, select a customer for home delivery order!',
                    });
                } else if(order && order.get_orderlines().length == 0){
                    await this.showPopup('ErrorPopup', {
                        title: 'Empty Cart?',
                        body: 'Should have atleast one product in your cart!',
                    });
                } else {
                    const users_list = this.env.pos.users_lst;
                    const { confirmed, payload: payload } = await this.showPopup('HomeDeliveryOrderPopup', {
                        title: this.env._t('Home Delivery Order?'),
                        body: this.env._t('Allow you to ship this products to customer doorstep!'),
                        addressChecked: false,
                        address_section: true,
                        usersList: users_list,
                    });
                    if (confirmed && payload) {
                        await this.createHomeDeliveryOrder(payload);
                    }
                }
            }
        }
    }

    HomeDeliveryButton.template = 'ShowHomeDeliveryButton';

    ProductScreen.addControlButton({
        component: HomeDeliveryButton,
        condition: function() {
            return this.env.pos.config.home_delivery;
        },
    });

    Registries.Component.add(HomeDeliveryButton);

    return HomeDeliveryButton;
});