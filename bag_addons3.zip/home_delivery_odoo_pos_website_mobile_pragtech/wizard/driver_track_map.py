from odoo import fields, api, models, _
from datetime import datetime, timedelta
from itertools import groupby


class DriverTrack(models.TransientModel):
    _name = 'driver.track.map'
    _description = 'Opening the map'

    def _default_driver(self):
        return self.env['res.partner'].search([('user_id', '=', self.env.uid), ('is_driver', '=', True)], limit=1)

    driver_ids = fields.Many2many(
        'res.partner', string="Driver", default=_default_driver, required=True)
    map_date = fields.Date('Date')

    def get_action(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Driver Track',
            'view_mode': 'google_map',
            'view_type': 'google_map',
            'res_model': 'driver.tracking',
            'context': self.env.context,
        }

    def action_send_msg2(self, from_date, to_date, driver):
        if from_date and to_date and driver:
            driver = list(map(int, driver))
            from_date = datetime.strptime(from_date, '%Y-%m-%d').date()
            to_date = datetime.strptime(to_date, '%Y-%m-%d').date()
            min = from_date
            max = to_date
            res = self.env['driver.tracking'].search_read([
                ('driver_id', 'in', driver),
                ('action_date', '>', min),
                ('action_date', '<', max)],
                fields=['driver_id', 'latitude', 'longitude', 'action_date', 'time_stamp_type'],
            )
            print('====================', res)
            # define a fuction for key
            def key_func(k):
                return k['driver_id']

            INFO = sorted(res, key=key_func)
            co = []
            co2 = []
            for key, value in groupby(INFO, key_func):
                data = list(value)
                l = []
                co.append({
                    key[1]: data
                })
                for v in data:
                    l.append([
                        float(v.get('latitude')),
                        float(v.get('longitude')),
                        v.get('time_stamp_type') == 'reached'])
                co2.append({
                    key[1]: l
                })
            return {
                'invalid': not co or not co2,
                'type': 'ir.actions.act_window',
                'name': 'Driver Track',
                'view_mode': 'google_map',
                'view_type': 'google_map',
                'res_model': 'driver.tracking',
                'context': {"coords": co, 'list_coords': co2},
            }
        return {
            'invalid': True
        }
