from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError, ValidationError


class PosConfigInherit(models.Model):
    _inherit = "pos.config"

    home_delivery = fields.Boolean('POS Home Delivery',default=False)

    floor_home_delivery = fields.Boolean('Display Home Delivery Button', default=False)
    floor_parcel = fields.Boolean('Display Parcel Button', default=False)

    module_pos_delivery_charge = fields.Boolean("Delivery Charge")
    delivery_charge_product_id = fields.Many2one('product.product', string='Delivery Charge Product',
        domain="[('sale_ok', '=', True)]")
    delivery_charge_amount = fields.Float(string='Delivey Charge Amount')

    module_pos_zone_charge = fields.Boolean("Zone Charge")
    zone_charge_product_id = fields.Many2one('product.product', string='Zone Charge Product',
        domain="[('sale_ok', '=', True)]")
    zone_charge_amount = fields.Float(string='Zone Charge Amount')

    @api.onchange('company_id','module_pos_delivery_charge')
    def _default_delivery_charge_product_id(self):
        product = self.env.ref("pragmatic_odoo_delivery_boy.product_delivery_charge", raise_if_not_found=False)
        self.delivery_charge_product_id = product if self.module_pos_delivery_charge and product and (not product.company_id or product.company_id == self.company_id) else False

    @api.onchange('company_id', 'module_pos_zone_charge')
    def _default_zone_charge_product_id(self):
        product = self.env.ref("pragmatic_odoo_delivery_boy.product_zone_charge", raise_if_not_found=False)
        self.zone_charge_product_id = product if self.module_pos_zone_charge and product and (not product.company_id or product.company_id == self.company_id) else False

    def write(self, vals):
        res = super(PosConfigInherit, self).write(vals)
        if (vals.get('module_pos_zone_charge') and self.module_pos_delivery_charge) or (vals.get('module_pos_delivery_charge') and self.module_pos_zone_charge):
            raise ValidationError(_('You can not set the Delivery Charge and Zone Charge at a time'))
        return res