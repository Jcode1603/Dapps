# -*- coding: utf-8 -*-

from odoo import api, fields, models

class PosOrder(models.Model):
	_inherit = "pos.order"

	def compute_salesperson(self):
		for rec in self:
			rec.salesperson_id = rec.lines[0].salesperson_id

	allow_orderline_user = fields.Boolean(related='session_id.config_id.allow_orderline_user')
	salesperson_id = fields.Many2one('res.users', string='Attendant',
										help='Attended who selected in pos', compute="compute_salesperson")


class PosOrderLine(models.Model):
	_inherit = "pos.order.line"

	salesperson_id = fields.Many2one('res.users', string='Attendant',
										help='Attended who selected in pos')

