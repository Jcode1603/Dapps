from odoo import http, _
from odoo.http import request
import json
from odoo.addons.web.controllers.main import Home

# class Home(Home):

#     @http.route()
#     def index(self, *args, **kw):
#         products = request.env['product.template'].sudo().search([], order="")

class LynviWebsite(http.Controller):
    @http.route('/lynvi/form_submit/<string:model_name>', type='http', auth='public', methods=['POST'], website=True)
    def conversation_info(self, model_name, **kwargs):
        email = kwargs.get('email_from')
        phone = kwargs.get('phone')
        trip_style = kwargs.get('dmform-6')
        type_of_travel = kwargs.get('dmform-8')
        message = kwargs.get('description')
        countries_in_offer = kwargs.get('countries_in_offer')
        no_of_adults_traveling = kwargs.get('no_of_adults_traveling')
        no_of_children = kwargs.get('no_of_children')
        check_in_date = kwargs.get('check_in_date')
        lodging_type = kwargs.get('What type of lodging do you want?')
        name = kwargs.get('name')
        per_person_budget = kwargs.get('per_person_budget')
        duration = kwargs.get('duration')
        must_haves = kwargs.get('must_have')
        exclude = kwargs.get('exclude')
        country_of_residence = kwargs.get('country')
        state = kwargs.get('state')
        city = kwargs.get('city')
        other_services = kwargs.get('Other Services Needed')
        include_international_flight = kwargs.get('Include_international_flights')
        try:
            # project = request.env['project.project'].sudo().search([('name', '=', 'Tour & Travel Forms')], limit=1)
            contact = request.env['res.partner'].sudo().create({'name': name, 'email': email, 'phone': phone})
            
            task = request.env['project.project'].sudo().create({'type_of_travel': type_of_travel, 'trip_style': trip_style, 'partner_id': contact.id,
                                                            'Number_of_adults': no_of_adults_traveling, 'Number_of_children': no_of_children, 
                                                            'countries_to_visit': countries_in_offer, 'message': message, 
                                                            'check_in_date': check_in_date, 'type_of_lodging': lodging_type, 
                                                            'per_person_budget': per_person_budget, 'duration': duration, 
                                                            'must_haves': must_haves, 'exclude': exclude, 'country_of_residence': country_of_residence, 
                                                            'state': state, 'city': city, 'name': name, 'other_services': other_services, 
                                                            'include_international_flight': include_international_flight})
            
            return json.dumps({'id': task.id})
        except:
            return json.dumps({
                'error': _("The form's data is incomplete, please fill form again")
            })

        