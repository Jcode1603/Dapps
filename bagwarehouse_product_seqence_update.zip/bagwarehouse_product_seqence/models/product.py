# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError

class ProductCategory(models.Model):
    _inherit = 'product.category'

    category_code = fields.Char(string='Code')

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    @api.model
    def _get_default_seq(self):
        return self.env["ir.sequence"].next_by_code("product.code")
    
    seq = fields.Char(string='Sequence', default=_get_default_seq)

    @api.onchange('categ_id')
    def _onchange_categ_id(self):
        self.default_code = str(self.categ_id.category_code) + self.seq
        self.barcode = str(self.categ_id.category_code) + self.seq

    @api.constrains('categ_id')
    def _restrict_category_code(self):
        if not self.categ_id.category_code:
            raise UserError('No code set on product category, please set category code')


class ProductProduct(models.Model):
    _inherit = 'product.product'

    @api.model
    def _get_default_seq(self):
        return self.env["ir.sequence"].next_by_code("product.code")
    
    seq = fields.Char(string='Sequence', default=_get_default_seq)

    @api.onchange('categ_id')
    def _onchange_categ_id(self):
        self.default_code = str(self.categ_id.category_code) + self.seq
        self.barcode = str(self.categ_id.category_code) + self.seq

    @api.constrains('categ_id')
    def _restrict_category_code(self):
        if not self.categ_id.category_code:
            raise UserError('No code set on product category, please set category code')