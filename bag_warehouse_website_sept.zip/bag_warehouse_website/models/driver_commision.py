from odoo import fields, models, api
from odoo.exceptions import ValidationError

class DriverCommission(models.Model):
    _name = 'driver.commission'

    @api.model
    def create(self, vals):
        res = super(DriverCommission, self).create(vals)
        driver_count = 0
        for driver in res.driver_ids:
            driver_exists = self.env['driver.commission'].sudo().search([('driver_ids', 'in', driver.id)])
            if len(driver_exists) > 1:
                driver_count += 1
        if driver_count > 0:
            raise ValidationError("Commission for this driver(s) already exists")
        return res
    
    # @api.depends("commission_type", "percentage", "price", "points")
    # def _compute_reward(self):
    #     for rec in self:
    #         if rec.commission_type == "fixed":
    #             rec.reward = rec.price
    #         elif rec.commission_type == "points":
    #             rec.reward = rec.points
    #         elif rec.commission_type == "percentage":
    #             rec.reward 

    driver_ids = fields.Many2many('res.partner', string="Dispatch drivers")
    commission_type = fields.Selection([('fixed', 'Fixed price per order'), ('percentage', 'Order price percentage'), ('points', 'Points per order')], string="Commission Type", default="points")
    percentage = fields.Float(string="Percentage")
    price = fields.Float(string="Fixed Price")
    points = fields.Float(string="Points")
    reward = fields.Float(string="Computed reward value")


class DriverPoints(models.Model):
    _name = 'driver.points'

    delivery_ref = fields.Many2one('picking.order', string="Order")
    date = fields.Datetime(default=fields.Datetime.now(), string="Date")
    partner = fields.Many2one('res.partner')
    reward = fields.Float(string="Commission")
    commission_type = fields.Selection([('fixed', 'Fixed price per order'), ('percentage', 'Order price percentage'), ('points', 'Points per order')], string="Type", default="points")

class PickingOrder(models.Model):
    _inherit = "picking.order"

    payment_terms = fields.Many2one('account.payment.term', string="Payment terms", related="sale_order.payment_term_id", store=True)

    def give_commission(self):
        commission = self.env["driver.commission"].sudo().search([('driver_ids', 'in', self.delivery_boy.id)], limit=1)
        if commission:
            reward = 0.0
            if commission.commission_type == "fixed":
                reward += commission.price
            elif commission.commission_type == "points":
                reward += commission.points
            elif commission.commission_type == "percentage":
                if commission.percentage > 0.0:
                    reward += (commission.percentage/100) * self.sale_order.amount_total
            points = self.env['driver.points'].sudo().create({'delivery_ref': self.id, 'partner': self.delivery_boy.id, 'reward':reward, 'commission_type': commission.commission_type})

        else:
            raise ValidationError("please configure commissions for this driver")
        


class ResPartner(models.Model):
    _inherit = "res.partner"

    # @api.depends('name', 'mobile')
    # def name_get(self):
    #     res = []
    #     for account in self:
    #         res.append((account.id, '%s %s' % (account.name, account.mobile or '') or (account.name)))
    #     return res

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        if args is None:
            args = []
        domain = args + ['|', ('mobile', operator, name), ('name', operator, name)]
        return self._search(domain, limit=limit, access_rights_uid=name_get_uid)

    driver_points = fields.One2many("driver.points", "partner")
    email = fields.Char(tracking=1)



