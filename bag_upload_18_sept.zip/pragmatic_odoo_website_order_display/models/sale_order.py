from odoo import api, fields, models, tools, _


class SaleOrder(models.Model):
    _inherit = "sale.order"

    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('progress', 'In Progress'),
        ('ready', 'Ready'),
        ('picked', 'Picked'),
        ('delivered', 'Delivered'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
        ], string='Status', readonly=True, copy=False, index=True, tracking=3, default='draft')


    def action_start(self):
        return self.write({'state': 'progress'})

    def action_complete(self):
        return self.write({'state': 'ready'})
    
class StockPicking(models.Model):
    _inherit = "stock.picking"

    def accept_order(self):
        self.write({'delivery_state': 'accept'})
        picking_order = self.env['picking.order'].search([('picking', '=', self.id)])
        if picking_order:
            picking_order.write({'state': 'accept'})

    def collect_payment(self):
        self.write({'delivery_state': 'paid', 'payment': 'paid'})
        picking_order = self.env['picking.order'].search([('picking', '=', self.id)])
        if picking_order:
            picking_order.write({'state': 'paid'})

    def button_validate(self):
        super(StockPicking, self).button_validate()
        self.write({'delivery_state': 'delivered'})
        picking_order = self.env['picking.order'].search([('picking', '=', self.id)])
        if picking_order:
            picking_order.write({'state': 'delivered'})

    delivery_boy = fields.Many2one('res.partner','Delivery Boy',domain="[('is_driver', '=', True),('status','=','available')]")
    payment = fields.Selection([
        ('unpaid', 'UnPaid'),
        ('paid', 'Paid'),
    ], string='Payment Status', readonly=True, copy=False, index=True, default='unpaid', tracking=True)
    payment_term_id = fields.Many2one('account.payment.term',string="Payment Term")

    delivery_state = fields.Selection([("assigned", "Assigned"), ('accept', 'Accepted by driver'), ('picked', 'Picked'),('paid', 'Paid'),('delivered', 'Delivered')], string="Delivery state")

class StockReturnPickingLine(models.TransientModel):
    _inherit = "stock.return.picking.line"

    to_refund = fields.Boolean(string="Update quantities on SO/PO", default=False, readonly=True,
        help='Trigger a decrease of the delivered/received quantity in the associated Sale Order/Purchase Order')