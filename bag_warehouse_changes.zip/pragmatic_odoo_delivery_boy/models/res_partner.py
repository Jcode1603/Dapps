from odoo import fields, models, api


class ResPartnerInherit(models.Model):
    _inherit = "res.partner"

    def default_get(self,fields):
        res = super(ResPartnerInherit, self).default_get(fields)
        Param = self.env['res.config.settings'].sudo().get_values()
        zone_charge_config_id = Param.get('zone_charge')
        if zone_charge_config_id:
            res['is_zone'] = True
        return res

    drive_rate = fields.Float("Driver Rate per KM")
    is_driver = fields.Boolean('Is a Driver', default=False)
    is_app_login = fields.Boolean(string='Is App Login', help="")
    device_imei_no = fields.Char(string='Device IMEI No.', help="")
    status = fields.Selection([('available', 'Available'), ('not_available', 'Not Available')],
                              string="Delivery Boy Status", default='available')
    driver_message = fields.Text(string='Driver Message')
    zone_configuration_id = fields.Many2one('zone.configuration', string='Zone')
    is_zone = fields.Boolean('Is Zone', compute='_compute_is_zone')

    def set_unset_delivery_boy(self):
        if self.is_driver == True:
            self.is_driver = False
        else:
            self.is_driver = True

    def write(self, vals):
        res = super(ResPartnerInherit, self).write(vals)
        if 'street' in vals or 'country_id' in vals or 'state_id' in vals:
            self.geo_localize()
        return res

    def _compute_is_zone(self):
        Param = self.env['res.config.settings'].sudo().get_values()
        zone_charge_config_id = Param.get('zone_charge')
        for rec in self:
            if zone_charge_config_id:
                rec.is_zone = True
            else:
                rec.zone_configuration_id = False
                rec.is_zone = False




