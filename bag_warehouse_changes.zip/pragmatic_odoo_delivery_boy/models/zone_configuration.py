# -*- coding: utf-8 -*-
from odoo import api, models, fields, _


class ZoneConfiguration(models.Model):
    _name = "zone.configuration"
    _rec_name = "name"

    name = fields.Char('Name')
    zone_price = fields.Float('Price')