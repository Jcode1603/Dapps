# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request, Response
from odoo.exceptions import ValidationError
import json

# login
# curl -i -H "Accept: application/json" -H "Content-type: application/json" -X POST --data "{\"username\": \"tobeokoli@yahoo.com\", \"password\": \"password\"}" http://localhost:8069/bagwarehouse_api/login

# Update product
# curl -H "Content-type: application/json" -X PUT -d "{\"name\": \"Tobenna Okoli\"}" http://localhost:8069/bagwarehouse_api/products/37

# Get products
# curl -H "Content-type: application/json" -H "Accept: application/json" -d {} -X GET http://localhost:8069/bagwarehouse_api/products

# Delete product
# curl -H "Content-type: application/json" -H "Accept: application/json" -X DELETE -d "{}" http://localhost:8069/bagwarehouse_api/products/40

# Create product
# curl -H "Content-type: application/json" -H "Accept: application/json" -d "{\"name\": \"Hello World\"}" -X POST http://localhost:8069/bagwarehouse_api/products


class BagwarehouseApi(http.Controller):

    @http.route('/bagwarehouse_api/login', auth='public', type='json', methods=['POST'], cors='*')
    def login(self, **kw):
        try:
            params = request.jsonrequest
            username = params.get('username')
            password = params.get('password')
            db = request.env.cr.dbname
            uid = request.session.authenticate(db, username, password)
            if uid:
                user = request.env['res.users'].sudo().browse(uid)
                session_token = request.session.session_token
                user_data = {
                    'session_token': session_token,
                    'name': user.name,
                    'email': user.email,
                    'phone': user.phone,
                    'image': user.image_128,
                }
                Response.status = '200'
                response = {'status': Response.status, 'data': user_data}
                return json.dumps(response, default=str)
        except Exception as e:
            Response.status = '400'
            response = {'status': Response.status, 'error': e}
            return json.dumps(response, default=str)

    @http.route('/bagwarehouse_api/logout', auth='user', type='json', cors='*')
    def logout(self, **kw):
        try:
            request.session.logout()
            Response.status = '200'
            response = {'status': Response.status, 'data': 'sucess'}
            return json.dumps(response, default=str)
        except Exception as e:
            Response.status = '400'
            response = {'status': Response.status, 'error': e}
            return json.dumps(response, default=str)

    @http.route(['/bagwarehouse_api/products', '/bagwarehouse_api/products/<string:id>'], auth='public', type='json', methods=['GET', 'POST', 'PUT', 'DELETE'], cors='*')
    def products(self, id=None, **kw):
        http_method = request.httprequest.method
        # READ (Tested)
        if http_method == 'GET':
            try:
                products = request.env['product.product'].sudo().search([])
                product_list = []
                for product in products:
                    product_data = {
                        'id': product.id,
                        'name': product.name,
                        # 'description': product.description,
                        # 'price': product.lst_price,
                        # 'image': product.image_128
                        # and other properties needed on the frontend
                    }
                    product_list.append(product_data)
                Response.status = '200'
                response = {'status': Response.status, 'data': product_list}
                return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'status': Response.status, 'data': e}
                return json.dumps(response, default=str)
        # CREATE (Tested)
        elif http_method == 'POST':
            data = request.jsonrequest
            try:
                product = request.env['product.product'].sudo().create(data).read()
                Response.status = '201'
                response = {'status': Response.status, 'data': product}
                return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'status': Response.status, 'error': e}
                return json.dumps(response, default=str)
        # UPDATE (Tested)
        elif http_method == 'PUT':
            id = json.loads(id)
            data = request.jsonrequest
            try:
                product = request.env['product.product'].sudo().browse(id)
                if not product:
                    Response.status = '404'
                    response = {'status': Response.status, 'error': 'Product not found'}
                    return json.dumps(response, default=str)
                else:
                    product.write(data)
                    product = request.env['product.product'].sudo().browse(id)
                    product_data = {
                        'id': product.id,
                        'name': product.name,
                    }
                    Response.status = '200'
                    response = {'status': Response.status, 'data': product_data}
                    return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'status': Response.status, 'error': e}
                return json.dumps(response, default=str)
        # DELETE 
        elif http_method == 'DELETE':
            id = json.loads(id)
            try:
                product = request.env['product.product'].sudo().search([('id', '=', id)])
                if not product:
                    Response.status = '404'
                    response = {'status': Response.status, 'error': 'Product not found'}
                    return json.dumps(response, default=str)
                else:
                    # return "is a product"
                    Response.status = '204'
                    response = {'status': Response.status, 'data': 'successfully deleted'}
                    product.unlink()
                    return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'status': Response.status, 'error': e}
                return json.dumps(response, default=str)

    def validate_variants_data(self, variants):
        for variant in variants:
            attribute_id1 = variant.get('attribute_id1')
            attribute_id2 = variant.get('attribute_id2')
            recs = request.env['product.template.attribute.value'].sudo().search([('id', 'in', [attribute_id1, attribute_id2])])
            if len(recs) != 2:
                raise ValidationError('Received non-existing attribute')
            else:
                return
            
    @http.route('/bagwarehouse_api/create_product_and_variants', auth='public', type='json', methods=['POST'], cors='*')
    def create_product_and_variants(self, **kw):
        # validate variants data
        try:
            params = request.jsonrequest
            product = params.get('product')
            variants = params.get('variants')
            self.validate_variants_data(variants)
            product_template = request.env['product.template'].sudo().create(product)
            for variant in variants:
                attribute_id1 = variant.get('attribute_id1')
                attribute_id2 = variant.get('attribute_id2')
                quantity = variant.get('quantity')
                request.env['product.product'].sudo().create({
                    'product_tmpl_id': product_template.id,
                    'product_template_attribute_value_ids': [(6, 0, [attribute_id1, attribute_id2])],
                    'lst_price': product_template.list_price,
                    'qty_available': quantity
                })
            Response.status = '201'
            response = {'status': Response.status, 'data': 'Success'}
            return json.dumps(response, default=str)
        except Exception as e:
            Response.status = '400'
            response = {'status': Response.status, 'error': e}
            return json.dumps(response, default=str)
        
    @http.route('/bagwarehouse_api/objects/<string:model>', auth='public', type='json', methods=['GET'], cors='*')
    def objects_list(self, model=None, **kw):
        try:
            recs = request.env[model].sudo().search([]).read()
            Response.status = '200'
            response = {'status': Response.status, 'data': recs}
            # response = {'status': Response.status, 'data': 'recs'}
            return json.dumps(response, default=str)
        except Exception as e:
            Response.status = '400'
            response = {'status': Response.status, 'error': e.args}
            return json.dumps(response, default=str)
            

