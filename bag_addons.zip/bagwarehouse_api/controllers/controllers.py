# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request, Response
import json

# login
# curl -i -H "Accept: application/json" -H "Content-type: application/json" -X POST --data "{\"username\": \"tobeokoli@yahoo.com\", \"password\": \"password\"}" http://localhost:8069/bagwarehouse_api/login

# Update product
# curl -H "Content-type: application/json" -X PUT -d "{\"name\": \"Tobenna Okoli\"}" http://localhost:8069/bagwarehouse_api/products/37

# Get products
# curl -H "Content-type: application/json" -H "Accept: application/json" -d {} -X GET http://localhost:8069/bagwarehouse_api/products

# Delete product
# curl -H "Content-type: application/json" -H "Accept: application/json" -X DELETE -d "{}" http://localhost:8069/bagwarehouse_api/products/40

# Create product
# curl -H "Content-type: application/json" -H "Accept: application/json" -d "{\"name\": \"Hello World\"}" -X POST http://localhost:8069/bagwarehouse_api/products


class BagwarehouseApi(http.Controller):

    @http.route('/bagwarehouse_api/login', auth='public', type='json', methods=['POST'])
    def login(self, **kw):
        try:
            params = request.get_json_data()
            username = params.get('username')
            password = params.get('password')
            db = request.env.cr.dbname
            uid = request.session.authenticate(db, username, password)
            if uid:
                user = request.env['res.users'].sudo().browse(uid)
                session_id = request.session.session_token
                user_data = {
                    'session_id': session_id,
                    'name': user.name,
                    'email': user.email,
                    'phone': user.phone,
                    'image': user.image_128,
                }
                Response.status = '200'
                response = {'data': user_data}
                return json.dumps(response, default=str)
        except Exception as e:
            Response.status = '400'
            response = {'error': e}
            return json.dumps(response, default=str)

    @http.route('/bagwarehouse_api/logout', auth='user', type='json')
    def logout(self, **kw):
        try:
            request.session.logout()
            Response.status = '200'
            response = {'data': 'sucess'}
            return json.dumps(response, default=str)
        except Exception as e:
            Response.status = '400'
            response = {'error': e}
            return json.dumps(response, default=str)

    @http.route(['/bagwarehouse_api/products', '/bagwarehouse_api/products/<string:id>'], auth='public', type='json', methods=['GET', 'POST', 'PUT', 'DELETE'])
    def products(self, id=None, **kw):
        http_method = request.httprequest.method
        # READ (Tested)
        if http_method == 'GET':
            try:
                products = request.env['product.product'].sudo().search([])
                product_list = []
                for product in products:
                    product_data = {
                        'id': product.id,
                        'name': product.name,
                        # 'description': product.description,
                        # 'price': product.lst_price,
                        # 'image': product.image_128
                        # and other properties needed on the frontend
                    }
                    product_list.append(product_data)
                Response.status = '200'
                response = {'data': product_list}
                return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'data': e}
                return json.dumps(response, default=str)
        # CREATE (Tested)
        elif http_method == 'POST':
            data = request.get_json_data()
            try:
                product = request.env['product.product'].sudo().create(data).read()
                Response.status = '201'
                response = {'data': product}
                return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'error': e}
                return json.dumps(response, default=str)
        # UPDATE (Tested)
        elif http_method == 'PUT':
            id = json.loads(id)
            data = request.get_json_data()
            try:
                product = request.env['product.product'].sudo().browse(id)
                if not product:
                    Response.status = '404'
                    response = {'error': 'Product not found'}
                    return json.dumps(response, default=str)
                else:
                    product.write(data)
                    product = request.env['product.product'].sudo().browse(id)
                    product_data = {
                        'id': product.id,
                        'name': product.name,
                    }
                    Response.status = '200'
                    response = {'data': product_data}
                    return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'error': e}
                return json.dumps(response, default=str)
        # DELETE 
        elif http_method == 'DELETE':
            id = json.loads(id)
            try:
                product = request.env['product.product'].sudo().search([('id', '=', id)])
                if not product:
                    Response.status = '404'
                    response = {'error': 'Product not found'}
                    return json.dumps(response, default=str)
                else:
                    # return "is a product"
                    Response.status = '204'
                    response = {'data': 'successfully deleted'}
                    product.unlink()
                    return json.dumps(response, default=str)
            except Exception as e:
                Response.status = '400'
                response = {'error': e}
                return json.dumps(response, default=str)
            

