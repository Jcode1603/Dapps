{
    'name': 'Delivery Confirm',
    'version': '14.0.0',
    'author': 'Pragmatic TechSoft Pvt Ltd.',
    'website': 'http://www.pragtech.co.in',
    'category': 'Website',
    'summary': '',
    'description': """ """,
    'depends': ['pragmatic_odoo_delivery_boy'],
    'data': [
        'views/picking_order_view.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
