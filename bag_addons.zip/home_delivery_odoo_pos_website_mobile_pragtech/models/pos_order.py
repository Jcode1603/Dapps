from odoo import models,fields,api


class PosOrderInherit(models.Model):
    _inherit = "pos.order"

    pos_delivery_order_ref = fields.Many2one('picking.order',string='Delivery Order Ref',readonly=True)
    delivery_type = fields.Selection([('home_delivery', 'Home Delivery'),
                                      ('default', 'Default')], string='Delivery Type', default='default')

    @api.model
    def create(self, vals):
        if vals.get('pos_reference'):
            pos_delivery_order = self.env['picking.order'].search([('name', '=', vals.get('pos_reference'))])
            if pos_delivery_order:
                vals['pos_delivery_order_ref'] = pos_delivery_order.id
                pos_delivery_order.write({'payment_status': 'Paid'})

        res = super(PosOrderInherit, self).create(vals)
        pos_delivery_order = self.env['picking.order'].search([('name', '=', res.pos_reference)])
        if pos_delivery_order:
            pos_delivery_order.pos_order_id = res
            pos_delivery_order.partner_id = res.partner_id
            delivery_address = res.partner_id.child_ids.filtered(lambda r:r.type == 'delivery')
            if not delivery_address:
                pos_delivery_order.partner_shipping_id = res.partner_id
            if delivery_address:
                pos_delivery_order.partner_shipping_id = delivery_address[-1]
        return res

    @api.model
    def _order_fields(self, ui_order):
        res = super(PosOrderInherit, self)._order_fields(ui_order)
        if not ui_order.get('table_id'):
            res['delivery_type'] = ui_order.get('delivery_type')
        return res

    def _create_order_picking(self):
        self.ensure_one()
        if not self.session_id.update_stock_at_closing or (self.company_id.anglo_saxon_accounting and self.to_invoice):
            picking_type = self.config_id.picking_type_id
            if self.partner_id.property_stock_customer:
                destination_id = self.partner_id.property_stock_customer.id
            elif not picking_type or not picking_type.default_location_dest_id:
                destination_id = self.env['stock.warehouse']._get_partner_locations()[0].id
            else:
                destination_id = picking_type.default_location_dest_id.id

            picking_order_id = self.env['picking.order'].search([('name', '=', self.pos_reference)])
            pickings = self.env['stock.picking'].with_context({'picking_order_id': picking_order_id.id})._create_picking_from_pos_order_lines(destination_id, self.lines, picking_type, self.partner_id)
            pickings.write({'pos_session_id': self.session_id.id, 'pos_order_id': self.id, 'origin': self.name})
            if picking_order_id:
                picking_order_id.write({'picking': pickings.id, 'pos_order_id': self.id})
                if picking_order_id.pos_order_id.payment_ids:
                    for payment in picking_order_id.pos_order_id.payment_ids:
                        picking_order_id.write({'acquirer_type': payment.payment_method_id.name})
                        if payment.payment_method_id.split_transactions:
                            picking_order_id.write({'payment': 'unpaid', 'payment_status': 'unpaid'})
                        elif payment.payment_method_id.journal_id.type in ['cash', 'bank']:
                            picking_order_id.write({'payment': 'paid', 'payment_status': 'paid'})
