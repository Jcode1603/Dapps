odoo.define('home_delivery_odoo_pos_website_mobile_pragtech.HomeDeliveryOrderPopup', function(require) {
    'use strict';

    const { useState, useRef } = owl.hooks;
    const { useListener } = require('web.custom_hooks');
    const AbstractAwaitablePopup = require('point_of_sale.AbstractAwaitablePopup');
    const Registries = require('point_of_sale.Registries');

    class HomeDeliveryOrderPopup extends AbstractAwaitablePopup {
        constructor() {
            super(...arguments);
            useListener('click-address-button', this._clickAddressButton);
            useListener('click-other-info', this._clickOtherInfo);
            this.state = useState({
                addressChecked: this.props.addressChecked,
                addressSection: this.props.address_section,
                isError: false,
                custName: "",
                custMobile: "",
                custEmail: "",
                custLocality: "",
                custStreet: "",
                custCity: "",
                custZip: "",
                deliveryPerson: "",
                custDeliveryTime: moment().format('YYYY-MM-DDThh:mm'),
                custDeliveryNote: ""
            });
            this.custNameRef = useRef('custName');
            this.checkboxAddressRef = useRef('checkboxAddress');
        }
        mounted() {
            if(this.custNameRef.el){
                this.custNameRef.el.focus();
            }else{
                this.checkboxAddressRef.el.focus();
            }
        }
        getPayload() {
            return this.state;
        }
        _clickOtherInfo(event) {
            this.state.addressSection = false;
        }
        _clickAddressButton(event) {
            this.state.addressSection = true;
        }
        _validateHomeDeliveryOrderFields(payload) {
            if(!payload.addressChecked || (payload.custName && payload.custEmail && payload.custMobile &&
            payload.custLocality && payload.custCity && payload.custZip))
                return true;
            return false;
        }
        async confirm() {
//            this.props.resolve({ confirmed: true, payload: await this.getPayload() });
            const payload = await this.getPayload();
            const is_valid = this._validateHomeDeliveryOrderFields(payload);
            if(is_valid)
                super.confirm(...arguments);
            else
                this.state.isError = true;
        }
    }

    HomeDeliveryOrderPopup.template = 'HomeDeliveryOrderPopup';

    HomeDeliveryOrderPopup.defaultProps = {
        confirmText: 'Create',
        cancelText: 'Cancel',
        clearText: 'Clear',
        title: 'Home Delivery Order?',
        body: 'Allow you to ship this products to customer doorstep!',
    };

    Registries.Component.add(HomeDeliveryOrderPopup);

    return HomeDeliveryOrderPopup;
});