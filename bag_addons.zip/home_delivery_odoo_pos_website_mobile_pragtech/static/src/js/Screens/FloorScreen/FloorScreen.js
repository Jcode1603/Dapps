odoo.define('home_delivery_odoo_pos_website_mobile_pragtech.FloorScreen', function (require) {
    'use strict';

    const FloorScreen = require('pos_restaurant.FloorScreen');
    const { useListener } = require('web.custom_hooks');
    const Registries = require('point_of_sale.Registries');

    const HomeDeliveryButton = (FloorScreen) =>
        class extends FloorScreen {
        constructor() {
            super(...arguments);
            useListener('click-home-delivery', (event) => this._clickHomeDelivery(event));
        }
        async _clickHomeDelivery(event) {
            this.env.pos.config.iface_floorplan = false;
            const orders = this.env.pos.get_order_list();
            const home_delivery_orders = orders.filter(order => order.delivery_type === 'home_delivery');

            if(!home_delivery_orders.length)
            {
                this.env.pos.table = null;
                this.env.pos.add_new_order();
                const order = this.env.pos.get_order();

                if(order){
                    order.set_delivery_type("home_delivery");
                    order.set_delivery_type_name("Home Delivery");
                }
            }else{
                this.env.pos.set_order(home_delivery_orders[0]);
            }
            this.env.pos.config.iface_floorplan = true;
            this.showScreen('ProductScreen');
        }
    };

    Registries.Component.extend(FloorScreen, HomeDeliveryButton);

    return HomeDeliveryButton;
});