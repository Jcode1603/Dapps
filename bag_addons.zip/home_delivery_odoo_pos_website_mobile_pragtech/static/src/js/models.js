odoo.define('home_delivery_odoo_pos_website_mobile_pragtech.models', function(require) {
    'use strict';

    var models = require('point_of_sale.models');

    models.load_models({
        model: 'res.partner',
        fields: ['id','name'], // fields that will be used from your model
        domain: function(self){ return [['is_driver','=',true]]; }, // domain filter
        loaded: function(self, data){
            self.users_lst = data;
        }
    });

    models.load_models({
        model:  'zone.configuration',
        fields: ['id', 'name'],
        loaded: function(self,zones){
            self.zones = zones;
            self.company.zone = null;
            for (var i = 0; i < zones.length; i++) {
                self.company.zone = zones[i];
            }
        },
    });

    models.load_fields('res.partner','zone_configuration_id');

    var _super_order_model = models.Order.prototype;
    models.Order = models.Order.extend({
        initialize: function(){
            _super_order_model.initialize.apply(this,arguments);
        },
        set_delivery_type: function(delivery_type){
            this.delivery_type = delivery_type;
        },
        get_delivery_type: function(){
            return this.delivery_type;
        },
        set_delivery_type_name: function(delivery_type_name) {
            this.delivery_type_name = delivery_type_name;
        },
        get_delivery_type_name: function(){
            return this.delivery_type_name;
        },
        export_as_JSON: function () {
            var json = _super_order_model.export_as_JSON.apply(this, arguments);
            json.delivery_type = this.get_delivery_type() || "default";
            json.delivery_type_name = this.get_delivery_type_name() || "Default";
            return json;
        },

        init_from_JSON: function (json) {
            _super_order_model.init_from_JSON.apply(this, arguments);
            this.delivery_type = json.delivery_type || "default";
            this.delivery_type_name = json.delivery_type_name || "Default";
        },

        export_for_printing: function() {
            var json = _super_order_model.export_for_printing.apply(this,arguments);
            json.delivery_type = this.get_delivery_type();
            return json;
        },

    });

});