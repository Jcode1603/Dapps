{
    'name': 'Pragmatic Delivery Mobile Driver',
    'version': '13.0.1.0.0',
    'author': 'Pragmatic TechSoft Pvt Ltd.',
    'website': 'http://www.pragtech.co.in',
    'category': 'Website',
    'summary': 'Pragmatic Delivery Mobile Driver Access',
    'description': """ Pragmatic Delivery Mobile Driver Access""",
    'depends': ['pragmatic_odoo_delivery_boy'],
    'data': [
        'security/ir.model.access.csv',
        'views/picking_order_view.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
