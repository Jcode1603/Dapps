# -*- coding: utf-8 -*-
{
    'name': 'Auto Reload Records',
    'version': '16.2',
    'author': 'Pragmatic TechSoft Pvt Ltd.',
    "website": "http://www.pragtech.co.in",
    'category': 'All View',
    'summary': 'All View',
    'description': """
     """,
    'depends': ['product', 'base', 'web', 'sale', 'purchase', 'account', 'stock', 'stock_picking_batch'],

    'data': [
        'views/product_view.xml',
        'views/sale_view.xml',
        'views/purchase_view.xml',
        'views/res_partner_view.xml',
        'views/account_move_view.xml',
        'views/stock_picking_view.xml',
    ],
    'images': [],
    'demo': [],
    'assets': {
       'web.assets_backend': [
           'pragmatic_auto_reload_records/static/src/js/button.js',
           'pragmatic_auto_reload_records/static/src/js/kanban_button.js',
       ],
        
        'web.assets_qweb': [
            'pragmatic_auto_reload_records/static/src/xml/**/*',
        ],
    },

    'license': 'OPL-1',
    'jquery': True,
    'bootstrap': True,
    'auto_install': False,
    'installable': True,
}
