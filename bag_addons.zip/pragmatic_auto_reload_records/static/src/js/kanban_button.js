odoo.define('pragmatic_auto_reload_records.kanban_button', function (require) {
    "use strict";

    var BasicController = require('web.BasicController');
    var core = require('web.core');
    var KanbanController = require('web.KanbanController');
    var KanbanView = require('web.KanbanView');
    var viewRegistry = require('web.view_registry');

    // KanbanView.include({
    //     renderButtons: function ($node) {
    //         debugger;
    //         this._super.apply(this, arguments);
    //         var $refresh_button = $('<button>')
    //             .addClass('btn btn-sm oe_highlight')
    //             .text('Refresh')
    //             .on('click', this.proxy('refreshKanbanData'));
    //         $refresh_button.appendTo($node);
    //     },
    // });

    var KanbanButton = KanbanController.extend({
        buttons_template: 'pragmatic_auto_reload_records.KanbanRefreshButton',
        events: _.extend({}, KanbanController.prototype.events, {
            'click .refresh_kanban_action': '_onclick_refresh',
        }),
        
        // custom_events: _.extend({}, KanbanController.prototype.custom_events, {
        //     'click .refresh_action': '_onclick_refresh',
        // }),
        _onclick_refresh: function () {
            var self = this;
            console.log("\n \n::::::::::::tttttt:")
            self.reload();
        }
    });
    // console.log("KanbanButton",KanbanButton)

    var SaleOrderKanbanView = KanbanView.extend({
        config: _.extend({}, KanbanView.prototype.config, {
            Controller: KanbanButton,
        }),
    });

    // return SaleOrderKanbanView;

    viewRegistry.add('button_in_kanban', SaleOrderKanbanView);

    // $(document).on('click', '.refresh_action', function(){
    //     $.ajax({
    //         url: '/path/to/refresh/data' + '/web',
    //         type: 'GET',
    //         dataType: 'html',
    //         success: function(response) {
    //             // Update the relevant part of the page with the new data
    //             $('#data-container').html(response);
    //         }
    //     });
    // });
});