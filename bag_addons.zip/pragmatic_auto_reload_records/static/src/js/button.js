odoo.define('pragmatic_auto_reload_records.tree_button', function (require) {
"use strict";
var ListController = require('web.ListController');
var ListView = require('web.ListView');
var viewRegistry = require('web.view_registry');
var TreeButton = ListController.extend({
   buttons_template: 'pragmatic_auto_reload_records.buttons',
   events: _.extend({}, ListController.prototype.events, {
       'click .refresh_action': '_onclick_refresh',
   }),
   _onclick_refresh: function () {
       var self = this;
       console.log("\n \n::::::::::::tttttt:")
       self.reload();
   }
});
var SaleOrderListView = ListView.extend({
   config: _.extend({}, ListView.prototype.config, {
       Controller: TreeButton,
   }),
});
viewRegistry.add('button_in_tree', SaleOrderListView);
});
// /** @odoo-module */
// import { registry } from '@web/core/registry';
// import { patch } from '@web/core/utils/patch';
// import { useService } from '@web/core/utils/hooks';
// import { listView } from "@web/views/list/list_view";

// import { ListController } from "@web/views/list/list_controller";
// import { ListRenderer } from "@web/views/list/list_renderer";

// const { onWillStart } = owl;

// console.log("\n \n:::Setup::::;")
// export class CustomListController extends ListController {
//     setup() {
//         super.setup();
//         this.orm = useService('orm');
//         this.actionService = useService('action');
//         this.rpc = useService("rpc");
//         this.user = useService("user");
//         // this.isExpenseSheet = this.model.rootParams.resModel === "hr.expense.sheet";
//         // this.isExpense = this.model.rootParams.resModel === "hr.expense";

//         // onWillStart(async () => {
//         //     this.is_expense_team_approver = await this.user.hasGroup("hr_expense.group_hr_expense_team_approver");
//         //     this.is_account_invoicing = await this.user.hasGroup("account.group_account_invoice");
//         // });
//     }

//     // displayCreateReport() {
//     //     return this.isExpense;
//     // }

//     // displaySubmit() {
//     //     const records = this.model.root.selection;
//     //     return records.length && records.every(record => record.data.state === 'draft') && this.isExpenseSheet;
//     // }

//     // displayApprove() {
//     //     const records = this.model.root.selection;
//     //     return this.is_expense_team_approver && records.length && records.every(record => record.data.state === 'submit') && this.isExpenseSheet;
//     // }

//     // displayPost() {
//     //     const records = this.model.root.selection;
//     //     return this.is_account_invoicing && records.length && records.every(record => record.data.state === 'approve') && this.isExpenseSheet;
//     // }

//     // async onClick (action) {
//     //     const records = this.model.root.selection;
//     //     const recordIds = records.map((a) => a.resId);
//     //     const model = this.model.rootParams.resModel;
//     //     await this.orm.call(model, action, [recordIds]);
//     //     // sgv note: we tried this.model.notify(); and does not work
//     //     await this.model.root.load();
//     //     this.render(true);
//     // }

//     async onClickReload() {
//         var self = this;
//         console.log("\n \n::::::::::::tttttt:")
//         self.reload();
//         // this.actionService.doAction(action);
//     }

// }
// // patch(CustomListController.prototype, 'expense_list_controller_upload', ExpenseDocumentUpload);

// // export class ExpenseListRenderer extends ListRenderer {}
// // patch(ExpenseListRenderer.prototype, 'expense_list_renderer_qrcode', ExpenseMobileQRCode);
// // patch(ExpenseListRenderer.prototype, 'expense_list_renderer_qrcode_dzone', ExpenseDocumentDropZone);
// // ExpenseListRenderer.template = 'hr_expense.ListRenderer';

// // export class ExpenseDashboardListRenderer extends ExpenseListRenderer {}

// // ExpenseDashboardListRenderer.components = { ...ExpenseDashboardListRenderer.components, ExpenseDashboard};
// // ExpenseDashboardListRenderer.template = 'hr_expense.DashboardListRenderer';

// // registry.category('views').add('hr_expense_tree', {
// //     ...listView,
// //     buttonTemplate: 'hr_expense.ListButtons',
// //     Controller: CustomListController,
// //     Renderer: ExpenseListRenderer,
// // });

// registry.category('views').add('button_in_tree', {
//     ...listView,
//     Controller: CustomListController,
// });

// // registry.category('views').add('test', {
// //     ...listView,
// //     // buttonTemplate: 'hr_expense.ListButtons',
// //     // Controller: CustomListController,
// //     Renderer: CustomListController,
// // });


// odoo.define('pragmatic_auto_reload_records.tree_button', function (require) {
//     "use strict";
//     var ListController = require('web.ListController');
//     var ListView = require('web.ListView');
//     var viewRegistry = require('web.view_registry');
//     var select_create_controllers_registry = require('web.select_create_controllers_registry');
//     var TreeButton = ListController.extend({
//     events: _.extend({}, ListController.prototype.events, {
//        'click .refresh_action': '_onclick_refresh',
//     }),
//    _onclick_refresh: function () {
//        var self = this;
//        console.log("\n \n::::::::::::tttttt:")
//        self.reload();
//    }
//     });
//     console.log("\n \n:TreeButton:", TreeButton)
// // var ProductListView = ListView.extend({
// //    config: _.extend({}, ListView.prototype.config, {
// //        Controller: TreeButton,
// //    }),
// // });
// // viewRegistry.add('button_in_tree', TreeButton);
//     _.extend(select_create_controllers_registry, {
//     TreeButton: TreeButton,
//     // SelectCreateKanbanController: SelectCreateKanbanController,
// });
// });
// // odoo.define('pragmatic_auto_reload_records.button_controllers_registry', function (require) {
// // "use strict";

// // return {};

// // });

// // odoo.define('pragmatic_auto_reload_records._button_controllers_registry', function (require) {
// // "use strict";

// // var KanbanController = require('web.KanbanController');
// // var ListController = require('web.ListController');
// // var button_controllers_registry = require('pragmatic_auto_reload_records.button_controllers_registry');

// // // var SelectCreateKanbanController = KanbanController.extend({
// // //     //--------------------------------------------------------------------------
// // //     // Handlers
// // //     //--------------------------------------------------------------------------

// // //     /**
// // //      * Override to select the clicked record instead of opening it
// // //      *
// // //      * @override
// // //      * @private
// // //      */
// // //     _onOpenRecord: function (ev) {
// // //         var selectedRecord = this.model.get(ev.data.id);
// // //         this.trigger_up('select_record', {
// // //             id: selectedRecord.res_id,
// // //             display_name: selectedRecord.data.display_name,
// // //         });
// // //     },
// // // });
// // export class ListController extends ListController {

// // var ButtonCreateListController = ListController.extend({
// //     //--------------------------------------------------------------------------
// //     // Handlers
// //     //--------------------------------------------------------------------------

// //     /**
// //      * Override to select the clicked record instead of opening it
// //      *
// //      * @override
// //      * @private
// //      */
// //     events: _.extend({}, ListController.prototype.events, {
// //        'click .refresh_action': '_onclick_refresh',
// //     }),
// //     // _onOpenRecord: function (ev) {
// //     //     var selectedRecord = this.model.get(ev.data.id);
// //     //     this.trigger_up('select_record', {
// //     //         id: selectedRecord.res_id,
// //     //         display_name: selectedRecord.data.display_name,
// //     //     });
// //     // },
// // });

// // _.extend(button_controllers_registry, {
// //     ButtonCreateListController: ButtonCreateListController,
// //     // SelectCreateKanbanController: SelectCreateKanbanController,
// // });

// // });