odoo.define('map.WebClient', function (require) {
    "use strict";

    var WebClient = require('web.WebClient');
    var base_bus = require('bus.Longpolling');
    var session = require('web.session');
    var core = require('web.core');
    require('bus.BusService');


    WebClient.include({
        show_application: function () {
            var res = this._super();
            this.start_polling();
            return res;
        },
        start_polling: function () {
            this.channel_success = 'update_map_route';
            this.all_channels = [
                this.channel_success,
            ];

            // startPolling to get this new tab registered,
            // in order to be able to call isMasterTab
            this.call('bus_service', 'startPolling');

            // - no need to add channels again if it was done already
            // - this is also a workaround for the infinite loop issue
            //   that occures when user logs in as a different user
            //   while still being logged in 2+ other tabs
            if(this.call('bus_service', 'isMasterTab')) {
                this.call('bus_service', 'addChannel', this.channel_success);
            }

            this.call(
                'bus_service', 'on', 'notification',
                this, this.bus_notification);
        },
        bus_notification: function (notifications) {
            var self = this;
            _.each(notifications, function (notification) {
                var channel = notification[0];
                var message = notification[1];
                if (
                    self.all_channels != null &&
                    self.all_channels.indexOf(channel) > -1
                ) {
                    self.on_message(channel,message);
                }
            });
        },
        on_message: function (channel,message) {
            core.bus.trigger('map_update', channel, message);
            // return this.call(
            //     'notification', 'notify', {
            //         type: message.type,
            //         title: message.title,
            //         message: message.message,
            //         sticky: message.sticky,
            //         className: message.className,
            //     }
            // );
        },
    });

});
