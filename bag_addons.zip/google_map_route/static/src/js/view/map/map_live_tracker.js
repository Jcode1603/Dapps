odoo.define('google_map_route.MapLiveTracker', function (require) {
    'use strict';

    var BasicRenderer = require('web.BasicRenderer');
    var MapRenderer = require('google_map_route.MapRenderer').MapRenderer;
    var core = require('web.core');
    var QWeb = require('web.QWeb');
    var session = require('web.session');
    var utils = require('web.utils');
    var Widget = require('web.Widget');
    var KanbanRecord = require('web.KanbanRecord');
    var Utils = require('google_map_route.Utils');
    var qweb = core.qweb;

    var history = [];
    MapRenderer.include({
        events: _.extend({}, MapRenderer.prototype.events, {
            'click #hide-slider': function (ev) {
                $('.mapController').animate({left: '-1000px'}, 1000);
                setTimeout(function () {
                    $('.mapController').addClass('d-none');
                    clearTimeout(this);
                }, 1000)
            },
            'click #show-slider': function (ev) {
                $('.mapController').animate({left: '0'}, 1000).removeClass('d-none');
            },
            'click #toggle-live-mode': function (ev) {
                var $target = $(ev.currentTarget);
                if ($target.hasClass('active')) {
                    //off
                    $target.removeClass('active');
                    this.live_mode = false;
                    this.clear_map_state(false);
                    $('.date-controller').show();
                    $('.animation-controller').show();
                    $('.animation-speed-controller').show();
                } else {
                    //on
                    $target.addClass('active');
                    this.live_mode = true;
                    this.clear_map_state(true);
                    $('.date-controller').hide();
                    $('.animation-controller').hide();
                    $('.animation-speed-controller').hide();
                }
            },
        }),
        getState: function (id) {
            if (this.state.context.previous_state) {
                id = id + '';
                return $.inArray(id, this.state.context.previous_state[2]) !== -1
            }
            return false;
        },
        _getLiveMarkers: function (driver_id) {
            // not sure what we do but i supose we get current marker instead of creating one always
            var self = this;
            var index = -1;
            _.each(self.live_markers, function (e, i) {
                if (e.driver_id == driver_id) {
                    index = i;
                }
            });
            if (index > -1) {
                return self.live_markers[index];
            }
            return false
        },
        _getDriver: function () {
            // returns array of object : [{'id','text'}]
            return $('#driver_selection').val();
        },
        _createNewLiveMarker: function (new_location) {
            var self = this;
            var map = self.gmap;
            var marker = new MarkerWithLabel({
                position: new google.maps.LatLng(new_location.latitude, new_location.longitude),
                icon: {
                    url: '/google_map_route/static/src/img/markers/man.png',
                    scaledSize: new google.maps.Size(50, 50)
                },
                title: new_location.driver,
                map: map,
                labelContent: new_location.driver,
                labelAnchor: new google.maps.Point(-21, 3),
                labelClass: "labels", // the CSS class for the label
                labelStyle: {opacity: 0.75},
            });
            const interval = setInterval(function () {
                $("img[src='https://maps.gstatic.com/mapfiles/transparent.png']").parent().tooltip({
                    placement: 'top',
                    trigger: 'manual'
                }).tooltip('show');
            }, 5000);
            // clearInterval(interval);

            self.live_markers.push({
                'driver_id': new_location.driver_id,
                'driver': new_location.driver,
                'marker': marker,
            });
        },
        live_plot_lines: function (start, end, complete, marker) {
            var self = this;
            var starting = start;
            var waypoints = [];
            end = end || [];
            _.each(complete, function (e) {
                waypoints.push({
                    stopover: false,
                    location: new google.maps.LatLng(e[0], e[1])
                })
                end = [e[0], e[1]];
            });
            var directionsService = new google.maps.DirectionsService();
            var directionsDisplay = new google.maps.DirectionsRenderer({
                map: this.gmap,
                preserveViewport: true
            });
            directionsService.route({
                origin: new google.maps.LatLng(starting[0], starting[1]),
                destination: new google.maps.LatLng(end[0], end[1]),
                waypoints: waypoints,
                optimizeWaypoints: true,
                travelMode: google.maps.TravelMode.DRIVING
            }, function (response, status) {
                if (status === google.maps.DirectionsStatus.OK) {
                    // directionsDisplay.setDirections(response);
                    var polyline = new google.maps.Polyline({
                        path: [],
                        strokeColor: '#0000FF',
                        strokeWeight: 3
                    });
                    var bounds = new google.maps.LatLngBounds();
                    var legs = response.routes[0].legs;
                    for (var l = 0; l < legs.length; l++) {
                        var steps = legs[l].steps;
                        for (var j = 0; j < steps.length; j++) {
                            var nextSegment = steps[j].path;
                            for (var k = 0; k < nextSegment.length; k++) {
                                polyline.getPath().push(nextSegment[k]);
                                bounds.extend(nextSegment[k]);
                            }
                        }
                    }
                    polyline.setMap(self.gmap);
                    self._updateLiveMarkerPosition(marker, polyline);
                    return polyline;
                } else {
                    window.alert('Directions request failed due to ' + status);
                }
            });
        },
        animateLiveMarker: function (marker, coords, km_h) {
            var self = this;
            var target = 0;
            var km_h = km_h || 50;
            var delay = 500;
            var timeout_move_marker = false, timeout_gotopoint = false;
            var coords = this.getArrayOfPath(coords);

            function goToPoint() {
                var lat = marker.position.lat();
                var lng = marker.position.lng();
                var step = (km_h * 1000 * delay) / 3600000; // in meters
                var dest = false;
                var tragetLTD = coords[target][0];
                var tragetLNG = coords[target][1];
                dest = new google.maps.LatLng(tragetLTD, tragetLNG);
                var distance =
                    google.maps.geometry.spherical.computeDistanceBetween(
                        dest, marker.position); // in meters

                var numStep = distance / step;
                var i = 0;
                var deltaLat = (tragetLTD - lat) / numStep;
                var deltaLng = (tragetLNG - lng) / numStep;

                function moveMarker() {
                    lat += deltaLat;
                    lng += deltaLng;
                    i += step;
                    if (i < distance) {
                        marker.setPosition(new google.maps.LatLng(lat, lng));
                        timeout_move_marker = setTimeout(moveMarker, delay);
                    } else {
                        marker.setPosition(dest);
                        target++;
                        timeout_gotopoint = setTimeout(goToPoint, delay);
                        if (target === coords.length) {
                            target = 0;
                            clearTimeout(timeout_move_marker);
                            clearTimeout(timeout_gotopoint);
                        }
                    }
                }

                moveMarker();
            }

            goToPoint();
        },
        _updateLiveMarkerPosition: function (marker, polyline) {
            var marker = marker.marker;
            this.animateLiveMarker(marker, polyline, 250);
        },
        _liveTrackerUpdate: function (channel, notify) {
            if (notify && notify.message == 'Live Location Updated' && this.live_mode) {
                if ($.inArray(notify.new_location.driver_id + "", this._getDriver()) < 0) {
                    console.log('Driver Not Selected!');
                    return;
                }
                var marker = this._getLiveMarkers(notify.new_location.driver_id);
                var new_location = notify.new_location;
                if (marker) {
                    var start = [marker.marker.getPosition().lat(), marker.marker.getPosition().lng()];
                    var end = [new_location.latitude, new_location.longitude];
                    var complete = [start, end];
                    this.live_plot_lines(start, end, complete, marker)
                } else {
                    this._createNewLiveMarker(new_location);
                }
            }
        },
        clear_map_state: function (state) {
            var self = this;
            self._rpc({
                model: 'driver.track.map',
                method: 'get_action',
                args: [[]]
            }).then(function (action) {
                action.views = [[false, 'google_map']];
                action.context['live_mode'] = state;
                self.do_action(action, {clear_breadcrumbs: true})
            })
        },
    });
});