{
    'name': 'Odoo WhatsApp Live Chat',
    'version': '15.0.0',
    'category': 'website',
    'author': 'Pragmatic TechSoft Pvt Ltd.',
    'website': "www.pragtech.co.in",
    'summary': 'Allow WhatsApp on odoo website live chat whatsapp live chat whatsapp chat',
    'description': "Allow WhatsApp on odoo website",
    'depends': ['website', 'base'],
    'data': [
        'security/ir.model.access.csv',
        "data/whatsapp_data.xml",
        'views/template.xml',
        'views/res_config_settings_view.xml',
        'views/whatsapp_chat_view.xml',
        'views/member_skills_view.xml',
        'views/website_view.xml'
        # 'views/res_company_view.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            '/pragmatic_odoo_whatsapp_live_chat/static/src/css/message_template.css',
            '/pragmatic_odoo_whatsapp_live_chat/static/src/css/live_chat.css',
            '/pragmatic_odoo_whatsapp_live_chat/static/src/js/whatsapp_live_chat_window.js'
        ],
    },
    'images': ['static/description/gif-Odoo-whatsapp-Live-Chat-min.gif'],
    'live_test_url': 'http://www.pragtech.co.in/company/proposal-form.html?id=103&name=Odoo-whatsapp-livechat',
    'license': 'OPL-1',
    'price': 49.00,
    'currency': 'USD',
    'installable': True,
    'auto_install': False,
    "cloc_exclude": [
        "**/*"
    ]
}
