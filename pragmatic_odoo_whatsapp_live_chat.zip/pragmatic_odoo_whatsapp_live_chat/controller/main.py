from odoo import http
from odoo.http import request
import requests
import base64
import json
import xmlrpc.client as xmlrpc
from datetime import datetime, timedelta

class send_whatsapp_message_live_chat(http.Controller):

    def convert_char_time(self, str_time):
        td = timedelta(hours=str_time)
        dt = datetime.min + td
        temp_date = dt.time()
        convert_time = format(temp_date)[:5]
        return convert_time

    @http.route('/send_whatsapp_message', auth='public', website=True, csrf=False)
    def send_whatsapp_message(self, **kw):
        return True

    @http.route('/live_chat_partner', type='http', auth='public', website=True)
    def live_chat_partner(self, page=0, search='', opg=False, domain=None, **kwargs):
        whatsapp_chat_ids = http.request.env['whatsapp.chat'].sudo().search([('active', '=', True), ('whatsapp_mobile', '!=', False),('whatsapp_text', '!=', False)])
        chat_partner_list = []
        for whatsapp_chat_id in whatsapp_chat_ids:
            chat_partner_dict = {}
            if whatsapp_chat_id:
                if whatsapp_chat_id.name:
                    chat_partner_dict['partner_name'] = whatsapp_chat_id.name
                if whatsapp_chat_id.whatsapp_mobile:
                    chat_partner_dict['partner_mobile'] = whatsapp_chat_id.whatsapp_mobile
                if whatsapp_chat_id.whatsapp_text:
                    chat_partner_dict['partner_message'] = whatsapp_chat_id.whatsapp_text
                if whatsapp_chat_id.member_skills_id.name:
                    chat_partner_dict['skill_id'] = whatsapp_chat_id.member_skills_id.name
                if whatsapp_chat_id.image_1920:
                    str_image = str(whatsapp_chat_id.image_1920)
                    chat_partner_dict['partner_image'] = str_image[2:-1]
                chat_partner_dict['time_from'] = self.convert_char_time(whatsapp_chat_id.time_from)
                chat_partner_dict['time_to'] = self.convert_char_time(whatsapp_chat_id.time_to)
                if chat_partner_dict:
                    chat_partner_list.append(chat_partner_dict)

        return json.dumps(chat_partner_list)









