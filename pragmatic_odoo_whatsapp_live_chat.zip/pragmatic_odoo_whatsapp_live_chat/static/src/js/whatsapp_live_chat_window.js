odoo.define("pragmatic_odoo_whatsapp_live_chat.whatsapp_live_chat_window", function(require){
	"use strict";


	$(document).ready(function(){
		console.log("In js whatsapp live chat")
       $('#website_whatsapp_icon').click(function(){

       		var output_speech=''
            var own_msg_section =''
            var output_partner_name =''
            var output_partner_mobile =''
            var output_partner_message =''
            var skill_id =''
            var time_from =''
            var time_to =''
            var partner_image =''
            console.log("In on click website_whatsapp_icon")
            $.ajax({
            url: '/live_chat_partner',
            type: "GET",
            cache : "false",
            success : function(odoo_data) {
                odoo_data= JSON.parse(odoo_data)
                for (var i = 0 ; i < odoo_data.length ; i++) {
                if (i === 0) { $('.user-message-section').remove();}
                output_partner_name = odoo_data[i].partner_name
                console.log("output_partner_name js: ",output_partner_name)
                output_partner_mobile = odoo_data[i].partner_mobile
                output_partner_message = odoo_data[i].partner_message
                skill_id = odoo_data[i].skill_id
                time_from = odoo_data[i].time_from
                time_to = odoo_data[i].time_to
                partner_image = odoo_data[i].partner_image
                if (output_partner_name && output_partner_mobile && output_partner_message)
                {
                    own_msg_section = '<a target="_blank" href="https://web.whatsapp.com/send?l=&phone='+ output_partner_mobile +'&text='+ output_partner_message +'"style="color: blue">'
                 }
                own_msg_section += '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'
                 if (partner_image)
                 {
                    own_msg_section += '<img style ="width:50px;height:50px;" src="data:image/png;base64,'+partner_image +'"/>'
                 }
                 if (output_partner_name)
                 {
                    own_msg_section += output_partner_name +'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                 }
                 if (skill_id)
                 {
                    own_msg_section += skill_id +'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                 }
                own_msg_section += time_from +'-'+ time_to +'</p></div></div></div></a>'
                console.log("After own_msg_sectionwn_msg_section js: ",own_msg_section)
                $(".message-body").append(own_msg_section)
        		}
        		 $('.inbox-wrapper').css('display','block');
        		         		 $('.message-container').css('display','block');

//                        		$(".message-container").toggle();
        		}
        		})

       });

       $('#onkey_press').keypress(function(e){
       console.log("In onkey_press")
        self = this
    	if(e.which === 13 ){
    		web_text_btn()
    	}
    })

    $('#web_text_btn').click(function(){
           console.log("In web_text_btn onclick")

    	web_text_btn()

    })

        $('#chatwindow_button_close').click(function(){
        $('.inbox-wrapper').css('display','none');
})

    function web_text_btn()
    {
		var msg = $(".msg-text").val()
		console.log("msg: ",msg)
		            console.log("In web_text_btn function")

		if (msg)
		{
			$.ajax({
			url: '/send_whatsapp_message',
			data:{'input_text':msg},
            beforeSend: function() {
                                          jQuery("#progressbar").css("display","block");
                                },
			})
//            .success(function(odoo_data)
//            {
//				jQuery("#progressbar").css("display","none");
//
//
//                if(odoo_data === undefined)
//                {
//                    output_speech="Please type something first"
//                    own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//                    $(".message-body").append(own_msg_section)
//                    $('.message-body').animate({ scrollTop: 99999 });
//                }
//
//                else if (odoo_data !== undefined)
//                {
//
//                    $(".msg-text").val("")
//
//                    own_msg_section = '<div class="own-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+msg +'</p></div></div></div>'
//                                    $(".message-body").append(own_msg_section)
//
//                    //								$('.message-body').animate({scrollTop:$(document).height()}, 'slow');
//                                    $('.message-body').animate({ scrollTop: 99999 });
//
//                    var data =
//                    {
//                        'message':msg,
//                    }
//
//
//
//                    if(odoo_data == 'No Response Error')
//                    {
//
//                        output_speech='Sorry for inconvenience. Please try again later'
//                        own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//                        $(".message-body").append(own_msg_section)
//                        $('.message-body').animate({ scrollTop: 99999 });
//                    }
//
//                    if(odoo_data == 'Test Connection Error')
//                    {
//
//                        output_speech="Please enter correct credentials, click on 'Connect now' button and try again"
//                        own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//                        $(".message-body").append(own_msg_section)
//                        $('.message-body').animate({ scrollTop: 99999 });
//
//                    }
//
//                    if(odoo_data == 'No Chatbot Instance Error')
//                    {
//
//                        output_speech="It seems you have not added the instance details. Please go to Chatbot => Chatbot Instance Details, Add your Odoo instance credentials and click on Connect Now button."
//                        own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//                        $(".message-body").append(own_msg_section)
//                        $('.message-body').animate({ scrollTop: 99999 });
//
//                    }
//
//                    // if(odoo_data == 'No Input Error')
//                    // {
//
//                    //     output_speech="Please type something first"
//                    //     own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//                    //     $(".message-body").append(own_msg_section)
//                    //     $('.message-body').animate({ scrollTop: 99999 });
//
//                    // }
//
//                    if(odoo_data != 'No Response Error' && odoo_data != 'Test Connection Error' && odoo_data != 'No Chatbot Instance Error' && odoo_data != 'No Input Error')
//                    {
//                        odoo_data= JSON.parse(odoo_data)
//                        output_speech = odoo_data['get_speech']
//
//
//                        // $(".msg-text").val("")
//
//                        // own_msg_section = '<div class="own-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+msg +'</p></div></div></div>'
//                        //                 $(".message-body").append(own_msg_section)
//
//                        // //								$('.message-body').animate({scrollTop:$(document).height()}, 'slow');
//                        //                 $('.message-body').animate({ scrollTop: 99999 });
//
//                        // var data =
//                        // {
//                        //     'message':msg,
//                        // }
//
//                        if(output_speech)
//                        {
//                            own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//                            $(".message-body").append(own_msg_section)
//                            $('.message-body').animate({ scrollTop: 99999 });
//                        }
//
//
//                    }
//                }
//
//			})
//			.error(function(error)
//			{
//				speech='Sorry for inconvenience. Please try again later';
//
//				if(error == 'No Response Error')
//				{
//					speech='Sorry for inconvenience. Please try again later'
//					own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ speech +'</p></div></div></div>'
//					$(".message-body").append(own_msg_section)
//					$('.message-body').animate({ scrollTop: 99999 });
//
//				}
//
//				else if(error == 'Test Connection Error')
//				{
//					speech="Please enter correct credentials, click on 'Connect now' button and try again"
//					own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ speech +'</p></div></div></div>'
//					$(".message-body").append(own_msg_section)
//					$('.message-body').animate({ scrollTop: 99999 });
//				}
//
//				else if(error == 'No Chatbot Instance Error')
//				{
//					output_speech="It seems you have not added the instance details. Please go to Chatbot => Chatbot Instance Details, Add your Odoo instance credentials and click on Connect Now button."
//					own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//					$(".message-body").append(own_msg_section)
//					$('.message-body').animate({ scrollTop: 99999 });
//
//                }
//
//                // else if(odoo_data == 'No Input Error')
//				// {
//
//				// 	output_speech="Please type something first"
//				// 	own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ output_speech +'</p></div></div></div>'
//				// 	$(".message-body").append(own_msg_section)
//				// 	$('.message-body').animate({ scrollTop: 99999 });
//
//                // }
//
//
//			})
		}
		else
		{
			speech='Please type something first'
			own_msg_section = '<div class="user-message-section"><div class="message-details own-message warning-icon"><div class="message-text sender_msg"><p>'+ speech +'</p></div></div></div>'
				$(".message-body").append(own_msg_section)
				$('.message-body').animate({ scrollTop: 99999 });
		}




    };



       });


	});

