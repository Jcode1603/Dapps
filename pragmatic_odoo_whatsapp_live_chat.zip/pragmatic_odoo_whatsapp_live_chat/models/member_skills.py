from odoo import fields, models


class MemberSkills(models.Model):
    _name = 'member.skills'
    _description = 'Member skills'

    name = fields.Char('Name')
