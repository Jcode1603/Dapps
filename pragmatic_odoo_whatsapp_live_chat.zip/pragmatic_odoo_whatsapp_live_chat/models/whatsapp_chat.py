from odoo import fields, models


class WhatsappChat(models.Model):
    _name = 'whatsapp.chat'
    _description = "Whatsapp Chat"
    # _inherit = ['image.mixin']

    name = fields.Char("Name", required=True)
    active = fields.Boolean('Active', default=True)
    time_from = fields.Float("Time from")
    time_to = fields.Float("Time to")
    whatsapp_text = fields.Text("Initial Message", required=True)
    member_skills_id = fields.Many2one("member.skills", "Member Skills")
    whatsapp_mobile = fields.Char("Whatsapp Number", required=True)
    res_partner_id = fields.Many2one("res.partner", "Partner")
    website_ids = fields.Many2many(
        'website', 'whatsapp_chat_website_rel',
        'wizard_id', 'website_id', 'Website')
    image_1920 = fields.Binary()
