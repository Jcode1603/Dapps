from odoo import api, fields, models

class website(models.Model):
    _inherit = 'website'

    # def get_image(self, a):
    #     #         if 'image' in a.keys():
    #     if 'image' in list(a.keys()):
    #         return True
    #     else:
    #         return False

    whatsapp_icon_img = fields.Binary(string="Image", required=True,attachment=True)
    whatsapp_icon_position = fields.Selection([('top-left','Top Left'),('top-center','Top Center'),('top-right','Top Right'),('left','Mid Left'),('center','Mid Center'),('right','Mid Right'),('bottom-left','Bottom Left'),('bottom-center','Bottom Center'),('bottom-right','Bottom Right')],string="Position")


class WebisteConfiguration(models.TransientModel):
    _inherit = 'res.config.settings'

    whatsapp_icon_img = fields.Binary(related="website_id.whatsapp_icon_img",string="Image", readonly = False)
    whatsapp_icon_position = fields.Selection(related="website_id.whatsapp_icon_position",string="Position", readonly = False)

