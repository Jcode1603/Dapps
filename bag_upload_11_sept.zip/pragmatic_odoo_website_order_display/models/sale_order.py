from odoo import api, fields, models, tools, _


class SaleOrder(models.Model):
    _inherit = "sale.order"

    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('progress', 'In Progress'),
        ('ready', 'Ready'),
        ('picked', 'Picked'),
        ('delivered', 'Delivered'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
        ], string='Status', readonly=True, copy=False, index=True, tracking=3, default='draft')


    def action_start(self):
        return self.write({'state': 'progress'})

    def action_complete(self):
        return self.write({'state': 'ready'})
    
class StockPicking(models.Model):
    _inherit = "stock.picking"

    delivery_boy = fields.Many2one('res.partner','Delivery Boy',domain="[('is_driver', '=', True),('status','=','available')]")

class StockReturnPickingLine(models.TransientModel):
    _inherit = "stock.return.picking.line"

    to_refund = fields.Boolean(string="Update quantities on SO/PO", default=False, readonly=True,
        help='Trigger a decrease of the delivered/received quantity in the associated Sale Order/Purchase Order')