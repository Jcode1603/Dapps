from odoo import models, fields, api, tools
from datetime import timedelta
import datetime

class HomeProducts(models.Model):
    _inherit = 'product.template'

    homepage_product = fields.Selection([('new', 'New'), ('featured', 'Featured'), ('top', 'Top Sellers'), ('deal', 'Deal of the day')], string="Homepage product listing")
    deal_expiry_date = fields.Datetime(string="Deal expiry date", required_if_homepage_product='deal')
    default_code = fields.Char(
        'SKU', compute='_compute_default_code',
        inverse='_set_default_code', store=True)

class Product(models.Model):
    _inherit = 'product.product'

    default_code = fields.Char('SKU', index=True)


class SaleOrder(models.Model):
    _inherit = 'product.product'

    user_id = fields.Many2one(
        'res.users', string='In-Store Attendant', index=True, tracking=2, default=lambda self: self.env.user,
        domain=lambda self: "[('groups_id', '=', {}), ('share', '=', False), ('company_ids', '=', company_id)]".format(
            self.env.ref("sales_team.group_sale_salesman").id
        ),)