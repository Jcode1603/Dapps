from odoo import models, fields, api, tools
from datetime import timedelta
import datetime

class HomeProducts(models.Model):
    _inherit = 'product.template'

    homepage_product = fields.Selection([('new', 'New'), ('featured', 'Featured'), ('top', 'Top Sellers'), ('deal', 'Deal of the day')], string="Homepage product listing")
    deal_expiry_date = fields.Datetime(string="Deal expiry date", required_if_homepage_product='deal')

# class SaleOrder(models.Model):
#     _inherit = 'sale.order'

#     payment_term_id = fields.Many2one(
#         'account.payment.term', string='PWD', check_company=True,  # Unrequired company
#         domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",)