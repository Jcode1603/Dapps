# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class SaleOrder(models.Model):
    _inherit = "sale.order"

    tracking_url = fields.Char(string="Tracking URL", compute="_get_tracking_url")

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()
        self._send_mail_confirm()
        return res

    def _send_mail_confirm(self):
        ctx = self.env.context.copy()
        template = self.env.ref('bagwarehouse_sale.sale_confirmation_email_template')
        template.with_context(ctx).send_mail(self.id, force_send=False)
        return True
    
    @api.depends('access_url')
    def _get_tracking_url(self):
        for record in self:
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            tracking_url = base_url + record.access_url
            record.tracking_url = tracking_url

