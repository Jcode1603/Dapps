# -*- coding: utf-8 -*-
{
    'name': "Bagswarehouseng Sales Extension",

    'summary': """
        Sales Extension module.""",

    'description': """
        this module is designed to handle the extensions to the sales feature
    """,

    'author': "Steve Olise",
    "license": "AGPL-3",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': [
        'base',
        'sale',
    ],

    'data': [
        'data/email_templates.xml',
    ],
}