# -*- coding: utf-8 -*-
{
    'name': "Product Code/Sequence Module",

    'summary': """
        Product Product Code/Sequence module.""",

    'description': """
        this module is designed to handle the product Product Code/Sequence feature
    """,

    'author': "Steve Olise",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': [
        'base',
        'stock',
    ],

    'data': [
        'data/sequence.xml',
        'views/views.xml',
    ],
}