from odoo import api, models, fields


class PickingOrder(models.Model):
    _inherit = "picking.order"

    is_signature = fields.Boolean(string="Signature Upload")
    is_delivery_image = fields.Boolean(string="Image Upload")
