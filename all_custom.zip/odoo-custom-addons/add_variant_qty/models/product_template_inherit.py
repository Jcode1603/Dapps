# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import itertools
import logging
from collections import defaultdict

from odoo import api, fields, models, tools, _, SUPERUSER_ID
from odoo.exceptions import ValidationError, RedirectWarning, UserError
from odoo.osv import expression

_logger = logging.getLogger(__name__)


class ProductTemplate(models.Model):
    _inherit = "product.template"
    _description = "Product Template Updates"

    stock_quant_ids = fields.One2many("stock.quant", "product_tmpl_qty_id", "Quantity")

    @api.model
    def create(self, vals_list):
        print("hellloooo\n")
        product_tmpl_id = super(ProductTemplate, self).create(vals_list)

        print("\n\nTemplate  ID :", product_tmpl_id.id)

        product_variants = self.env["product.product"].search(
            [("product_tmpl_id", "=", product_tmpl_id.id)]
        )

        print("\n\nVariants: ", product_variants)

        all_stock_records = []
        
        stock_quant = self.env['stock.quant']

        for variant in product_variants:
            print(variant)
            
            locations = self.env['stock.location'].search([('usage', 'in', ['internal', 'transit'])])
            

            all_stock_records.append(
                (
                    0,
                    0,
                    {"product_id": variant.id, "product_tmpl_id": product_tmpl_id.id, 'location_id': locations[0].id},
                )
            )

        for record in self.stock_quant_ids:
            record.unlink()
            
        print(all_stock_records)

        product_tmpl_id.stock_quant_ids = all_stock_records
        
        return product_tmpl_id
    
    # def action_load_variants(self):
    #     pass
        


class ProductQuant(models.Model):
    _name = "product.quant"
    _description = "Update Stock Quant from Product Template"

    product_tmpl_id = fields.Many2one("product.template")
    product_id = fields.Many2one("product.product", "Variant")
    qty = fields.Integer("Quantity")
    
    # location_id = fields.Many2one(
    #     'stock.location', 'Location',
    #     domain=lambda self: self._domain_location_id(),
    #     auto_join=True, ondelete='restrict', required=True, index=True, check_company=True)
    # lot_id = fields.Many2one(
    #     'stock.production.lot', 'Lot/Serial Number', index=True,)
    


class ProductVariant(models.Model):
    _inherit = "product.product"
    _description = "Product Template Updates"

    stock_quant_ids = fields.One2many("product.quant", "product_id", "Quantity")



class StockQuant(models.Model):
    
    _inherit = 'stock.quant'
    
    user_id = fields.Many2one(
        'res.users', 'Assigned To',default=lambda self: self.env.user.id, help="User assigned to do product count.")

    
