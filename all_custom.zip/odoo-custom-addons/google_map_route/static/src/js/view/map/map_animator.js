odoo.define('google_map_route.MapAnimator', function (require) {
    'use strict';

    var BasicRenderer = require('web.BasicRenderer');
    var MapRenderer = require('google_map_route.MapRenderer').MapRenderer;
    var core = require('web.core');
    var QWeb = require('web.QWeb');
    var session = require('web.session');
    var utils = require('web.utils');
    var Widget = require('web.Widget');
    var KanbanRecord = require('web.KanbanRecord');
    var Utils = require('google_map_route.Utils');
    var qweb = core.qweb;

    /*Helper Functions*/
    function convertTZ(date, tzString) {
        if (date) {
            return new Date((typeof date === "string" ? new Date(date) : date).toLocaleString("en-US", {timeZone: tzString}));
        } else {
            return new Date(new Date().toLocaleString("en-US", {timeZone: tzString}));
        }
    }

    var smax = 0;
    var sratio = 0;
    var sindex = 0;
    var su_ratio = 0;

    return MapRenderer.include({
        events: {
            'select2-selecting #driver_selection': function (ev) {
                if (ev.val == 'all') {
                    $("#driver_selection > option").prop("selected", "selected");// Select All Options
                    $("#driver_selection").trigger("change");// Trigger change to select 2
                    setTimeout(function () {
                        $("#driver_selection > option[value='all']").prop("selected", false);// Select All Options
                        $("#driver_selection").trigger("change");// Trigger change to select 2
                    }, 10);
                }
            },
            'change #action_date_from,#action_date_to,#driver_selection': function (ev) {
                var driver = $('select').select2('val');
                if ($.inArray('all', driver) > -1) {
                    return;
                }
                var from_date = $('#action_date_from').val();
                var to_date = $('#action_date_to').val();
                console.log("\n \n:to_date::::", to_date)
                if (from_date && to_date && driver) {
                    this.restart_app(from_date, to_date, driver);
                }
            },
            'change .add-speed': function (ev) {
                var self = this;
                var driver = $('select').select2('val');
                if (!driver.length) {
                    alert('Please Select Driver First?');
                    return;
                }
                self.speed = parseInt($(ev.currentTarget).val() || 150);
                self.update_speed();
            },
            'click .btn-minus': function (ev) {
                var self = this;
                var driver = $('select').select2('val');
                alert(driver.length);
                if (!driver.length) {
                    alert('Please Select Driver First?');
                    return;
                }
                self.speed = self.speed - 1;
                self.update_speed();
            },
            'click .btn-plus': function (ev) {
                var self = this;
                var driver = $('select').select2('val');
                if (!driver.length) {
                    alert('Please Select Driver First?');
                    return;
                }
                self.speed = self.speed + 1;
                self.update_speed();
            },
            'click .play_pause': function (ev) {
                var target = $(ev.currentTarget);
                var driver = $('select').select2('val');
                if (!driver.length) {
                    alert('Please Select Driver First?');
                    return;
                }
                var self = this;
                target.toggleClass("paused");
                for (var i = 0; i < self.animator.length; i++) {
                    var marker = self.animator[i].marker
                    if (target.hasClass('paused')) {
                        //resume animation
                        this.animate = true;
                        this.animateMarker(marker,
                            self.animator[i].coords,
                            self.animator[i].km_h, i);
                    } else {
                        //pause animation
                        self.pauseMarker(i);
                        var lat = marker.position.lat();
                        var lng = marker.position.lng();
                        self.animator[i]['current_pos'] = [lat, lng];
                    }
                }
            },
            'input #map_slider': function (ev) {
                var driver = $('select').select2('val');
                if (!driver.length) {
                    alert('Please Select Driver First?');
                    return;
                }
                var tz = this.state.context.tz;
                var target = $(ev.currentTarget);
                var self = this;
                var $playButton = self.$el.find('.play_pause');
                if ($playButton.hasClass('paused')) {
                    $playButton.trigger('click');
                }
                var control = target,
                    controlMin = control.attr('min'),
                    controlMax = control.attr('max'),
                    controlVal = control.val(),
                    controlThumbWidth = control.data('thumbwidth');
                if (controlVal - 1 === (self.animator[0].coords.length) - 1) {
                    return false;
                }
                var range = controlMax - controlMin;
                var position = ((controlVal - controlMin) / range) * 100;
                var positionOffset = Math.round(controlThumbWidth * position / 100) - (controlThumbWidth / 2);
                var output = control.next('output');
                var p = [];
                var closest = self.closest(self.animator[0], controlVal);
                var bubble = convertTZ(closest, tz);
                bubble = bubble.getHours() + ":" + bubble.getMinutes() + ":" + bubble.getSeconds();
                output
                    .css('left', 'calc(' + position + '% - ' + positionOffset + 'px)')
                    .text(bubble);
                for (var i = 0; i < self.animator.length; i++) {
                    var marker = self.animator[i].marker
                    self.slideMarker(marker, self.animator[i].coords,
                        self.animator[i].km_h, parseInt(controlVal), i);
                }
            },
        },
        closest: function (animator, position) {
            var position = parseInt(position);
            if (position >= su_ratio) {
                su_ratio = su_ratio + sratio;
                sindex = sindex + 1;
            }
            if (su_ratio >= position) {
                su_ratio = su_ratio - sratio;
                sindex = sindex - 1;
            }
            var dt = animator.rcoords && animator.rcoords[sindex] && animator.rcoords[sindex]['action_date'];
            if (!dt) {
                dt = animator.rcoords && animator.rcoords[sindex] && animator.rcoords[sindex - 1]['action_date']
            }
            return dt;
        },
        slideMarker: function (marker, coords, km_h, target = 0, index = 0) {
            var self = this;
            if (!coords[target]) {
                return;
            }
            self.updateLastMarkerSlide(target);
            var position = [];
            if (self.animator[index]['current_pos']) {
                position = [self.animator[index]['current_pos'][0], self.animator[index]['current_pos'][1]];
            } else {
                position = [coords[target][0], coords[target][1]];
            }

            function goToPoint() {
                var tragetLTD = coords[target][0];
                var tragetLNG = coords[target][1];
                var numDeltas = 100;
                var i = 0;

                function transition() {
                    i = 0;
                    moveMarker2();
                }

                function moveMarker2() {
                    var latlng = new google.maps.LatLng(position[0], position[1]);
                    marker.setPosition(latlng);
                    if (i !== numDeltas) {
                        i++;
                        moveMarker2()
                    }
                }

                self.animator[index]['current_pos'] = [tragetLTD, tragetLNG];
                // self.current_pos = [tragetLTD, tragetLNG];
                transition();
            }

            goToPoint();
        },
        updateLastMarkerSlide: function (target) {
            this.last_target = target
        },
        updateLastMarker: function (target) {
            var self = this;
            if (self.last_target) {
                self.last_target = self.last_target + 1
            } else {
                self.last_target = target;
            }
        },
        pauseMarker: function (index) {
            var self = this;
            if (self.animator[index]) {
                clearTimeout(self.animator[index].timeout_gotopoint);
                clearTimeout(self.animator[index].timeout_move_marker);
            }
        },
        update_speed: function () {
            var self = this;
            $('.add-speed').val(self.speed);
            self.animator[0].km_h = self.speed;
        },
        restart_app: function (from_date, to_date, driver) {
            var self = this;
            self._rpc({
                model: 'driver.track.map',
                method: 'action_send_msg2',
                args: [[], from_date, to_date, driver]
            }).then(function (action) {
                if (action.invalid == true) {
                    alert('Tracking Not exits!!')
                    return false;
                }
                action.views = [[false, 'google_map']]
                action.context['previous_state'] = [from_date, to_date, driver];
                self.do_action(action, {clear_breadcrumbs: true})
            })
        },
        init: function (parent, state, params) {
            this._super.apply(this, arguments);
            this.coords = this.state.context.coords;
            this.list_coords = this.state.context.list_coords;
            this.animator = [];
            this.speed = 150;
            this.live_mode = false;
            this.live_markers = [];
            if (this.state.context) {
                this.live_mode = this.state.context.live_mode;
                this.live_markers = this.state.context.live_markers || [];
            }
        },
        willStart: function () {
            var self = this;
            self.driver = [];
            var defs = [this._super(), this.read_data()];
            return $.when.apply($, defs);
        },
        start: function () {
            var self = this;
            self.company_id = 1;
            if (odoo && odoo.session_info) {
                self.company_id = odoo.session_info.company_id;
            }
            self._initMap();
            self.$el.find("#driver_selection").select2();
            core.bus.on('map_update', this, this._liveTrackerUpdate);
            return this._super();
        },
        read_data: function () {
            var self = this;
            return self._rpc({
                model: 'res.partner',
                method: 'search_read',
                args: [[['is_driver', '=', true || 1]], []],
                kwargs: {},
            }).then(function (emp) {
                self.driver = emp;
            });
        },
        _initMap: function () {
            this.infoWindow = new google.maps.InfoWindow();
            this.$right_sidebar = this.$('.o_map_right_sidebar');
            console.log("\n \n::test:::::")
            this.$('.o_map_view').empty();
            this.gmap = new google.maps.Map(this.$('.o_map_view').get(0), {
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                minZoom: 3,
                maxZoom: 20,
                fullscreenControl: true,
                mapTypeControl: true,
            });
            var self = this;
            _.each(self.coords, function (main, index) {
                _.each(main, function (sub, ssindex) {
                    for (var i = 0; i < sub.length; i++) {
                        var marker = new google.maps.Marker({
                            position: new google.maps.LatLng(sub[i].latitude, sub[i].longitude),
                            icon: {
                                url: '/google_map_route/static/src/img/markers/map_stop.png',
                                scaledSize: new google.maps.Size(12, 12)
                            },
                            map: self.gmap,
                        });
                        main[ssindex][i].pos = marker.getPosition();
                        main[ssindex][i].stop = marker;
                    }
                });
            });
            this._getMapTheme();
            var func_name = '_post_load_map_' + this.mapMode;
            this[func_name].call(this);
            _.each(this.list_coords, function (e, i) {
                _.each(e, function (sub, ssindex) {
                    self.plot_lines(sub, ssindex, i);
                });
            });
        },
        get_initial_coords: function (index, i) {
            if (this.state.context.coords) {
                return [this.state.context.coords[i][index][0].latitude,
                    this.state.context.coords[i][index][0].longitude
                ]
            }
            return [0, 0]
        },
        plot_lines: function (list_coords, index, i) {
            var self = this;
            var starting = this.get_initial_coords(index, i);
            var end = [];
            var waypoints = [];
            _.each(list_coords, function (e) {
                waypoints.push({
                    stopover: e[2],
                    location: new google.maps.LatLng(e[0], e[1])
                })
                end = [e[0], e[1]];
            });
            var directionsService = new google.maps.DirectionsService();
            var directionsDisplay = new google.maps.DirectionsRenderer({
                map: this.gmap,
                preserveViewport: true
            });
            directionsService.route({
                origin: new google.maps.LatLng(starting[0], starting[1]),
                destination: new google.maps.LatLng(end[0], end[1]),
                waypoints: waypoints,
                optimizeWaypoints: true,
                travelMode: google.maps.TravelMode.DRIVING
            }, function (response, status) {
                if (status === google.maps.DirectionsStatus.OK) {
                    // directionsDisplay.setDirections(response);
                    var polyline = new google.maps.Polyline({
                        path: [],
                        strokeColor: '#0000FF',
                        strokeWeight: 3
                    });
                    var bounds = new google.maps.LatLngBounds();
                    var legs = response.routes[0].legs;
                    for (var l = 0; l < legs.length; l++) {
                        var steps = legs[l].steps;
                        for (var j = 0; j < steps.length; j++) {
                            var nextSegment = steps[j].path;
                            for (var k = 0; k < nextSegment.length; k++) {
                                polyline.getPath().push(nextSegment[k]);
                                bounds.extend(nextSegment[k]);
                            }
                        }
                    }
                    polyline.setMap(self.gmap);
                    self.init_animation(polyline, starting, index, i);
                } else {
                    window.alert('Directions request failed due to ' + status);
                }
            });
        },
        getArrayOfPath: function (polyline) {
            var vertices = polyline.getPath();
            var real_coords = []
            for (let i = 0; i < vertices.getLength(); i++) {
                var xy = vertices.getAt(i);
                real_coords.push([xy.lat(), xy.lng()]);
            }
            return real_coords
        },
        get_latest_speed: function () {
            var self = this;
            if (self.animator[0].km_h) {
                var km_h = self.animator[0].km_h;
                return km_h;
            }
        },
        animateMarker: function (marker, coords, km_h, index) {
            var self = this;
            var target = 0;
            var km_h = km_h || 50;
            var delay = self.animator[0].delay || 500;

            function goToPoint() {
                var lat = marker.position.lat();
                var lng = marker.position.lng();
                km_h = self.get_latest_speed() || km_h;
                var step = (km_h * 1000 * delay) / 3600000; // in meters
                var dest = false;
                var tragetLTD = coords[target][0];
                var tragetLNG = coords[target][1];
                var val = self.last_target || target;
                if ((coords.length - 1) === (val - 1)) {
                    self.pauseMarker();
                    return false;
                }
                self.$el.find('#map_slider').val(val);
                if (self.animator[index]['current_pos']) {
                    tragetLTD = coords[val] && coords[val][0];
                    tragetLNG = coords[val] && coords[val][1];
                    if (!tragetLTD || !tragetLNG) {
                        return false;
                    }
                }

                dest = new google.maps.LatLng(tragetLTD, tragetLNG);
                var distance =
                    google.maps.geometry.spherical.computeDistanceBetween(
                        dest, marker.position); // in meters

                var numStep = distance / step;
                var i = 0;
                var deltaLat = (tragetLTD - lat) / numStep;
                var deltaLng = (tragetLNG - lng) / numStep;

                function moveMarker() {
                    lat += deltaLat;
                    lng += deltaLng;
                    i += step;
                    if (i < distance) {
                        marker.setPosition(new google.maps.LatLng(lat, lng));
                        var timeout_move_marker = setTimeout(moveMarker, delay);
                        self.animator[index]['timeout_move_marker'] = timeout_move_marker;
                    } else {
                        marker.setPosition(dest);
                        target++;
                        var timeout_gotopoint = setTimeout(goToPoint, delay);
                        self.animator[index]['timeout_gotopoint'] = timeout_gotopoint;
                        if (target === coords.length) {
                            target = 0;
                            self.pauseMarker();
                        }
                        if (self.last_target === coords.length) {
                            self.last_target = 0;
                            self.pauseMarker();
                        }
                        self.updateLastMarker(target);
                    }
                }

                moveMarker();
            }

            goToPoint();
        },
        init_animation: function (polyline, starting, index, i) {
            var map, marker;
            var startPos = starting;
            var speed = this.speed; // km/h
            var self = this;
            var delay = 100;
            var real_coords = this.getArrayOfPath(polyline);

            function indexOfLongest(arrays) {
                var longest = -1;
                for (var i = 0; i < arrays.length; i++) {
                    if (longest == -1 || arrays[i]['rcoords'].length > arrays[longest]['rcoords'].length) {
                        longest = i;
                    }
                }
                return arrays[longest]['rcoords'].length;
            }

            function initialize() {
                map = self.gmap;
                marker = new google.maps.Marker({
                    position: new google.maps.LatLng(startPos[0], startPos[1]),
                    icon: {
                        url: '/google_map_route/static/src/img/markers/man.png',
                        scaledSize: new google.maps.Size(50, 50)
                    },
                    title: index,
                    map: map
                });
                const interval = setInterval(function () {
                    $("img[src='https://maps.gstatic.com/mapfiles/transparent.png']").parent().tooltip({
                        placement: 'top',
                        trigger: 'manual'
                    }).tooltip('show');
                }, 5000);
                // clearInterval(interval);
                self.animator.push({
                    marker: marker,
                    map: map,
                    coords: real_coords,
                    km_h: speed,
                    delay: delay,
                    driver: index,
                    rcoords: self.coords[i][index],
                })
                self.compare_init_slider();
                smax = parseInt(self.$el.find('#map_slider').attr('max'));
                sratio = Math.round(smax / indexOfLongest(self.animator));
                sindex = 0;
                su_ratio = sratio;
                // self.map_init = true;
            }

            if (!self.map_init) {
                initialize();
            }
        },
        compare_init_slider: function () {
            var self = this;
            var max = 0;
            for (var i = 0; i < self.animator.length; i++) {
                var c = self.animator[i]['coords'].length;
                if (max < c) {
                    max = c;
                }
            }
            self.animator.map(a => a.length)
            self.$el.find('#map_slider').attr('max', max);
            return max
        },
        _renderMarkers: function () {
            var self = this,
                color,
                latLng,
                lat,
                lng,
                defaultLatLng = this._getDefaultCoordinate();

            _.each(this.state.data, function (record) {
                color = self._getIconColor(record);
                lat =
                    typeof record.data[self.fieldLat] === 'number'
                        ? record.data[self.fieldLat]
                        : 0.0;
                lng =
                    typeof record.data[self.fieldLng] === 'number'
                        ? record.data[self.fieldLng]
                        : 0.0;
                if (record.data) {
                    lat = record.data.fieldLat;
                    lng = record.data.fieldLng;
                }
                if (lat === 0.0 && lng === 0.0) {
                    self._createMarker(defaultLatLng, record, color);
                } else {
                    latLng = new google.maps.LatLng(lat, lng);
                    self._createMarker(latLng, record, color);
                }
            });
        },
    })

});