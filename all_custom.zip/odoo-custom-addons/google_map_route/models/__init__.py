# -*- coding: utf-8 -*-
# License AGPL-3
from . import ir_act_window_view
from . import ir_ui_view
from . import res_config_settings
from . import res_partner
