
Google Map integration with Odoo
============================================
Pragmatic has developed module which provides the integration between Google map and Odoo. 


