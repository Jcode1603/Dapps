import json
import logging
from werkzeug.exceptions import Forbidden, NotFound
import googlemaps

from odoo import fields, http, SUPERUSER_ID, tools, _
from odoo.http import request
from odoo.addons.website_sale.controllers.main import WebsiteSale
_logger = logging.getLogger(__name__)


class WebsiteSaleInherit(WebsiteSale):

    @http.route(['/shop/address'], type='http', methods=['GET', 'POST'], auth="public", website=True, sitemap=False)
    def address(self, **kw):
        Partner = request.env['res.partner'].with_context(show_address=1).sudo()
        order = request.website.sale_get_order()

        redirection = self.checkout_redirection(order)
        if redirection:
            return redirection

        mode = (False, False)
        can_edit_vat = False
        values, errors = {}, {}

        partner_id = int(kw.get('partner_id', -1))

        # IF PUBLIC ORDER
        if order.partner_id.id == request.website.user_id.sudo().partner_id.id:
            mode = ('new', 'billing')
            can_edit_vat = True
        # IF ORDER LINKED TO A PARTNER
        else:
            if partner_id > 0:
                if partner_id == order.partner_id.id:
                    mode = ('edit', 'billing')
                    can_edit_vat = order.partner_id.can_edit_vat()
                else:
                    shippings = Partner.search([('id', 'child_of', order.partner_id.commercial_partner_id.ids)])
                    if order.partner_id.commercial_partner_id.id == partner_id:
                        mode = ('new', 'shipping')
                        partner_id = -1
                    elif partner_id in shippings.mapped('id'):
                        mode = ('edit', 'shipping')
                    else:
                        return Forbidden()
                if mode and partner_id != -1:
                    values = Partner.browse(partner_id)
            elif partner_id == -1:
                mode = ('new', 'shipping')
            else: # no mode - refresh without post?
                return request.redirect('/shop/checkout')

        # IF POSTED
        if 'submitted' in kw and request.httprequest.method == "POST":
            pre_values = self.values_preprocess(order, mode, kw)
            errors, error_msg = self.checkout_form_validate(mode, kw, pre_values)
            post, errors, error_msg = self.values_postprocess(order, mode, pre_values, errors, error_msg)
            if pre_values.get('zone_id'):
                post.update({'zone_configuration_id':pre_values.get('zone_id')})
            if errors:
                errors['error_message'] = error_msg
                values = kw
            else:
                partner_id = self._checkout_form_save(mode, post, kw)
                if mode[1] == 'billing':
                    order.partner_id = partner_id
                    order.with_context(not_self_saleperson=True).onchange_partner_id()
                    # This is the *only* thing that the front end user will see/edit anyway when choosing billing address
                    order.partner_invoice_id = partner_id
                    if not kw.get('use_same'):
                        kw['callback'] = kw.get('callback') or \
                            (not order.only_services and (mode[0] == 'edit' and '/shop/checkout' or '/shop/address'))
                elif mode[1] == 'shipping':
                    order.partner_shipping_id = partner_id

                # TDE FIXME: don't ever do this
                # -> TDE: you are the guy that did what we should never do in commit e6f038a
                order.message_partner_ids = [(4, partner_id), (3, request.website.partner_id.id)]
                if not errors:
                    return request.redirect(kw.get('callback') or '/shop/confirm_order')

        render_values = {
            'website_sale_order': order,
            'partner_id': partner_id,
            'mode': mode,
            'checkout': values,
            'can_edit_vat': can_edit_vat,
            'error': errors,
            'callback': kw.get('callback'),
            'only_services': order and order.only_services,
        }
        render_values.update(self._get_country_related_render_values(kw, render_values))
        render_values.update(self._update_zone_values(kw,render_values))
        return request.render("website_sale.address", render_values)

    def _update_zone_values(self,kw,render_values):
        zone = request.env['zone.configuration'].sudo()
        zones = zone.search([])
        res={
            'zone':zone,
            'zones':zones,
        }
        return res

    @http.route(['/shop/order/update_zone/'], type='json', auth="public", methods=['POST'], website=True, csrf=False)
    def order_update_zone(self, zone_id=None, **kw):
        """
        this method used to add or update zone charge in order
        """
        order = request.website.sale_get_order(force_create=1)
        order.update_order_zone(zone_id)
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    @http.route(['/get_google_api_key'], type='json', auth="public", methods=['POST'], website=True, csrf=False)
    def get_google_api_key(self, **kw):
        api_key = http.request.env['ir.config_parameter'].sudo().search([('key', '=', 'google.api_key_geocode')])
        return api_key.value

    @http.route(['/get_source_dest_location'], type='json', auth="public", methods=['POST'], website=True, csrf=False)
    def get_source_dest_location(self, order_id=None, **kw):
        res = {'result':False,"message":"Something went wrong!"}
        if order_id:
            order = request.env['sale.order'].sudo().browse(int(order_id))

            picking_order = request.env['picking.order'].search([('sale_order', '=', order.id)],limit=1)

            if picking_order and picking_order.state == 'picked':
                google_api_key = request.env['ir.config_parameter'].sudo().get_param('google.api_key_geocode')
                # gmaps = googlemaps.Client(key=google_api_key)
                delivery_boy = picking_order.delivery_boy

                if delivery_boy and order.partner_shipping_id.partner_latitude and order.partner_shipping_id.partner_longitude:
                    if order.partner_shipping_id.partner_latitude and order.partner_shipping_id.partner_longitude and delivery_boy.partner_latitude and delivery_boy.partner_longitude:
                        source = (
                        delivery_boy.partner_latitude, delivery_boy.partner_longitude)
                        destination = (order.partner_shipping_id.partner_latitude, order.partner_shipping_id.partner_longitude)

                    elif not order.partner_shipping_id.partner_latitude and order.partner_shipping_id.partner_longitude:
                        res.update({'result': False, 'message': "Partner's Latitude and Longitude is missing"})

                    else:
                        res.update({'result': False, 'message': "Delivery Boy's Latitude and Longitude is missing"})

                    try:
                        # distance = gmaps.distance_matrix(source, destination)["rows"][0]["elements"][0]["distance"]
                        # distance_btn_2_loc = distance['value'] * 0.002
                        res.update({'result': True, 'message': 'Success',
                                    'source_loc':source,'dest_loc':destination,
                                    'distance':'distance','distance_btn_2_loc':'distance_btn_2_loc'})

                    except Exception as e:
                        _logger.error(_("Invalid source or destination address."))
                        _logger.exception(e)
                        res.update({'result': False, 'message': e})

            elif picking_order and picking_order.state != 'picked':
                res.update({'result': False, 'message': "Order is {}".format(picking_order.state)})

        else:
            res.update({'result':False,'message':"Order Not Found"})

        print("\n\n res >>>>>>>>>> ",res,'\n\n')
        return res

    @http.route(['/get_driver_live_location'], type='json', auth="public", methods=['POST'], website=True, csrf=False)
    def get_driver_live_location(self, order_id=None, **kw):
        if order_id:
            order = request.env['sale.order'].sudo().browse(int(order_id))

            picking_order = request.env['picking.order'].search([('sale_order', '=', order.id)],limit=1)

            lat = picking_order.delivery_boy.partner_latitude,
            lng = picking_order.delivery_boy.partner_longitude

            print("\n\nUpdate lat lng : ",lat,lng,'\n\n')
            return {'lat':lat,'lng':lng}

    # def address(self, **kw):
    #     print("222222222222222222222222",**kw)
    #     res = super(WebsiteSaleInherit, self).address(**kw)
    #     print("111111111111111111111111111111",res)
    #     return res
