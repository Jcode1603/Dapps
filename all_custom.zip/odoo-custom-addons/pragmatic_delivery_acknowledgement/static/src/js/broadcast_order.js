odoo.define("pragmatic_delivery_acknowledgement.broadcast_order", function(require){
	"use strict";
	$(document).ready(function(){
        var main_nav = $(".o_main_navbar");
        console.log(main_nav);

        // if (main_nav.length !== 0) {
        //     $(".o_main_navbar").css("margin-top","-46px");
        //     $("#wrapwrap").css("margin-top","-26px");
        //     $(".o_main_navbar").hide();
        // }
        
        //$(".o_main_navbar").empty(); -->
        $("#footer").hide();
        //$("#wrapwrap").hide();
        
        
        console.log("this works");
        console.log($("#footer"));
        console.log($(".img-fluid"));
	    $('.broadcast_accept_order').on('click',function(){
            var order_number = document.getElementById("order_number").value
            var value = {
					"delivery_order_status" : "accept",
					"order_number" : order_number
			}
            $.ajax({
                url : '/broadcast/accept_broadcast_order',
                data : value,
                success: function(res) {
                    var vals = $.parseJSON(res)
                    if (vals['status'] == true)
                    {vals
                        window.location.reload();
                    }
                }
            });
        });
	});
});
