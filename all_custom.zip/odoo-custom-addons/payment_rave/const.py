# EVENT SENT BY FLUTTERWAVE

EVENTS = {
    'CHARGE': 'charge.completed',
    'TRANSFER' : 'transfer.completed',
}