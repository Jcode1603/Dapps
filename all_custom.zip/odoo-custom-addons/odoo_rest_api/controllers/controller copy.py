from odoo import http, _ , fields
from datetime import date
from odoo.http import request
from odoo.http import Response
from functools import wraps
import requests
import json
import base64
import psycopg2
import sys


class rest_error():
    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                response = request.make_response(json.dumps({'error': str(e)}),headers=[('content-type','application/json')])
                response.status_code = 200
                return response
        return wrapper

class json_rest_error():
    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                response = {'error': str(e)}
                print("Came TO ERROR ZONE")
                # Response.status = "400 BAD Response"
                return response
        return wrapper


class Main(http.Controller):

    @staticmethod
    def login(model_str, res_ids=False,params=False,get=False):
        data = dict()
        data_bytes = request.httprequest.stream.read()

        if data_bytes:
            data = data_bytes.decode("utf-8")
            json_acceptable_string = data.replace("'", "\"")
            data = json.loads(json_acceptable_string)

            if 'context' in data:
                request.context = dict(data['context'])
                data.pop('context')
        jdata = request.httprequest.environ['HTTP_AUTHORIZATION'].split(' ')[1]
        user, password = base64.b64decode(jdata).decode("utf-8", "ignore").split(':')
        request.env.uid = request.session.authenticate(request.session.db, user, password)
        data = json.loads("{\"user_id\":" + str(request.env.uid)+"}")
        model = request.env[model_str]
        obj_to_call = model
        return obj_to_call, data

    @staticmethod
    def common(model_str, res_ids=False,params=False,login=False,use_data=False):
        data = dict()
        data_bytes = request.httprequest.stream.read()

        if use_data:
    
            data = data_bytes.decode("utf-8")
            json_acceptable_string = data.replace("'", "\"")
            data = json.loads(json_acceptable_string)

            if 'context' in data:
                request.context = dict(data['context'])
                data.pop('context')
        jdata = request.httprequest.environ['HTTP_AUTHORIZATION'].split(' ')[1]
        user, password = base64.b64decode(jdata).decode("utf-8", "ignore").split(':')
        request.env.uid = request.session.authenticate(request.session.db, user, password)
        model = request.env[model_str]  
        print(model)      
        obj_to_call = model
        if login :
            if str(request.env.uid) != "False":
                user_data = {}
                user_data['domain'] = [['id','=',str(request.env.uid)]]
                user_data['fields'] = ['id','name','employee_ids']
                get_user = getattr(obj_to_call, 'search_read')(**user_data)
                print(get_user)
                if len(get_user) > 0:
                    data = {"user_id": str(request.env.uid),"name": get_user[0]['name'],"employee_ids": get_user[0]['employee_ids'],"role_ids": "" }
                else:
                    data = {"user_id": "False"}
            else:    
                data = {"user_id": str(request.env.uid)}
            return obj_to_call, data
        
        
        if res_ids:
            res_ids = '[' + res_ids + ']'
            obj_to_call = model.browse(json.loads(res_ids))
        return obj_to_call, data

    @staticmethod
    def jsoncommon(model_str, res_ids=False,params=False,login=False):
        # data = dict()
        # data_bytes = request.httprequest.stream.read()

        # if data_bytes:
        #     data = data_bytes.decode("utf-8")
        #     json_acceptable_string = data.replace("'", "\"")
        #     data = json.loads(json_acceptable_string)

        #     if 'context' in data:
        #         request.context = dict(data['context'])
        #         data.pop('context')
        print(request.httprequest.headers)
        jdata = request.httprequest.headers['Authorization'].split(' ')[1]
        user, password = base64.b64decode(jdata).decode("utf-8", "ignore").split(':')
        request.env.uid = request.session.authenticate(request.session.db, user, password)
        model = request.env[model_str]        
        obj_to_call = model
        if login :
            if str(request.env.uid) != "False":
                user_data = {}
                user_data['domain'] = [['id','=',str(request.env.uid)]]
                user_data['fields'] = ['id','name','employee_ids']
                get_user = getattr(obj_to_call, 'search_read')(**user_data)

                # print(get_user)
                print(get_user)
                data = {"user_id": str(request.env.uid),"name": get_user[0]['name'],"employee_ids": get_user[0]['employee_ids'],"role_ids": ""}      
            else:    
                data = {"user_id": str(request.env.uid)}
            return obj_to_call
        
        
        # if res_ids:
        #     res_ids = '[' + res_ids + ']'
        #     obj_to_call = model.browse(json.loads(res_ids))
        return obj_to_call

    @staticmethod
    def parse_result(result,run=False):
        try:
            if run:
                return json.dumps(result)
            else:
                return request.make_response(json.dumps(result),headers=[('content-type','application/json')])
        except:
            return request.make_response(str(result))

    @rest_error()
    @http.route(['/customer/login/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False)
    def login_user(self, model_str,field=False,value=False,old_acc_no=False,acc_no=False,run=False):
        #print(field + value)
        obj_to_call, data = self.common(model_str,login=True)
        return self.parse_result(data)
    
    @rest_error()
    @http.route(['/customer/find/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False)
    def query_read_cus(self, model_str,field=False,value=False,old_acc_no=False,acc_no=False,run=False,partner_id=False):
        #print(field + value)
        
        obj_to_call, data = self.common(model_str)
        # print(data)

        data['fields'] = ['id','name','old_acc_no','acc_no','credit','customer_class','tariff','feeder_id','transformer_id','lastPayDate','lastPayAmount','billedAmount','vat','billDate','district','customer_category','allow_meter','metering_type','street','meter_no']
        if old_acc_no:
            data['domain'] = [['old_acc_no','=',old_acc_no]]
        if acc_no:
            data['domain'] = [['acc_no','=',acc_no]]

        if partner_id:
            if len(str(partner_id)) > 7:
                data['domain'] = [['old_acc_no','=',partner_id]] 
            else:
                data['domain'] = [['acc_no','=',partner_id]]                
        #print(data)

        if run:
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data),run=True)
        else:
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data))

    @rest_error()
    @http.route(['/app/getfeederreadings/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False,cors="*")
    def query_read_app_getfeederreading(self, model_str,field=False,value=False,employee_id=False,month=False,year=False,run=False):
        #print(field + value)
        
        obj_to_call, data = self.common(model_str)
        # print(data)

        district = 0
        data['fields'] = ['id','name','ava_factor','adjusted_av','e_imported']
        if employee_id:
            # url = "http://74.208.145.137:8069/app/marketer/marketer?employee_id=%s" % (employee_id)
            # r = requests.get(url, auth=('ossyogbo@yahoo.com','EedcOsita@123'))
            # get_user = r.json() 
            user_data = {}
            user_data['domain'] = [['id','=',employee_id]]
            user_data['fields'] = ['id','x_district']
            special_call = request.env['hr.employee']
            get_user = getattr(special_call, 'search_read')(**user_data)
            rows = []

            if len(get_user) > 0:
                
                if get_user[0]['x_district']:
                    district = get_user[0]['x_district'][0];
                                
            data['domain'] = [['name.district_id.id','=',district],['month','=',8],['year','=',2019]]

        # if acc_no:
        #     data['domain'] = [['acc_no','=',acc_no]]
        #print(data)

        
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data))

    @rest_error()
    @http.route(['/app/getfeeders/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False,cors="*")
    def query_read_app_getfeeders(self, model_str,field=False,value=False,employee_id=False,acc_no=False,run=False):
        #print(field + value)
        
        obj_to_call, data = self.common(model_str)
        # print(data)

        district = 0
        data['fields'] = ['id','name']
        if employee_id:
            # url = "http://74.208.145.137:8069/app/marketer/marketer?employee_id=%s" % (employee_id)
            # r = requests.get(url, auth=('ossyogbo@yahoo.com','EedcOsita@123'))
            # get_user = r.json() 
            user_data = {}
            user_data['domain'] = [['id','=',employee_id]]
            user_data['fields'] = ['id','x_district']
            special_call = request.env['hr.employee']
            get_user = getattr(special_call, 'search_read')(**user_data)
            rows = []

            if len(get_user) > 0:
                
                if get_user[0]['x_district']:
                    district = get_user[0]['x_district'][0];
                                
            data['domain'] = [['district_id.id','=',district]]

        # if acc_no:
        #     data['domain'] = [['acc_no','=',acc_no]]
        #print(data)

        
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data))
    @rest_error()
    @http.route(['/app/getcustomers/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False)
    def query_read_app_getcustomers(self, model_str,field=False,value=False,employee_id=False,acc_no=False,run=False):
        #print(field + value)
        
        obj_to_call, data = self.common(model_str)
        # print(data)

        marketer_id = 0
        rows = []
        data['fields'] = ['id','name','feeder_id','acc_no','old_acc_no','customer_class','tariff','transformer_id','district','previous_reading','book_id','allow_meter','metering_type']
        if employee_id:
            # url = "http://74.208.145.137:8069/app/marketer/marketer?employee_id=%s" % (employee_id)
            # r = requests.get(url, auth=('ossyogbo@yahoo.com','EedcOsita@123'))
            # get_user = r.json() 
            default_book = {"book_id_id": 00000,"feeder_id": [" ",34876],"name": "SENATORGILBERTNNAJI","previous_reading": '',"id": 125977,"book_id": [00000,"Pick A Book"],"tariff": "","allow_meter": False,"district": [" ",4],"transformer_id": [" ",66002],"customer_class": [" ",23],"old_acc_no": "60/16/94/0271-01","acc_no": "6832392518","metering_type": "postpaid"}

            cursor = request.env.cr
            cursor.execute("select c.id,c.name,c.feeder_id,acc_no,old_acc_no,c.customer_class,'' as tariff,c.transformer_id,c.district,bill.current_read as previous_reading,b.name as book_id,allow_meter,metering_type,b.id as book_id_id  from res_partner c LEFT JOIN feeder_customer_details bill ON customer_ids = c.id and e_month = 8 and e_year = 2019 LEFT JOIN book_feeder b ON b.id = c.book_id LEFT JOIN service_center s ON s.id = b.service_id and x_employee = '%s'::int  where customer_category = 'MD' and c.bill_status = True and b.book_code is not null and old_acc_no is not null and s.name is not null and s.x_employee = '%s'::int Order by b.book_code" % (str(employee_id),str(employee_id))) 

            records = cursor.dictfetchall()

            # print("select c.id,c.name,c.feeder_id,acc_no,old_acc_no,c.customer_class,'' as tariff,c.transformer_id,c.district,bill.current_read as previous_reading,b.name as book_id,allow_meter,metering_type  from res_partner c LEFT JOIN feeder_customer_details bill ON customer_ids = c.id and e_month = 8 and e_year = 2019 LEFT JOIN book_feeder b ON b.id = c.book_id LEFT JOIN service_center s ON s.id = b.service_id and x_employee = '%s'  where customer_category = 'MD' and c.bill_status = True and b.book_code is not null and old_acc_no is not null and s.name is not null and s.x_employee = '%s' Order by b.book_code")
            count = 0
            rows.append(default_book)
            for x in records:
                records[count]['book_id']= [records[count]['book_id_id'],records[count]['book_id']] 
                records[count]['transformer_id']= [" ",records[count]['transformer_id']]    
                records[count]['feeder_id']= [" ",records[count]['feeder_id']]
                records[count]['district']= [" ",records[count]['district']]    
                records[count]['customer_class']= [" ",records[count]['customer_class']]    
                count = count + 1
                rows.append(x)
            return self.parse_result(rows)


            user_data = {}
            user_data['domain'] = [['marketer_employee_id.id','=',employee_id]]
            user_data['fields'] = ['id','book']
            special_call = request.env['marketer']
            get_user = getattr(special_call, 'search_read')(**user_data)
            
            if len(get_user) > 0:
                print(get_user)
                marketer_id = get_user[0]['id']
                test_data = {"fields": ['customers','display_name']}
                test_model = request.env['book.feeder'].browse(get_user[0]['book'])

                # print()
                #GET ALL CUSTOMERS
                mybooks = getattr(test_model, 'read')(**test_data);
                
                for books in mybooks:
                    rows.extend(books['customers'])
                print(rows)
            # data['domain'] = [['marketer','=',marketer_id]]

        # if acc_no:
        #     data['domain'] = [['acc_no','=',acc_no]]
        #print(data)

        if run:
            return self.parse_result(getattr(obj_to_call.browse(rows), 'read')(**data),run=True)
        else:
            return self.parse_result(getattr(obj_to_call.browse(rows), 'read')(**data))

    @rest_error()
    @http.route(['/login/getuser/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False)
    def query_read(self, model_str,field=False,value=False,user_id=False,acc_no=False,run=False):
        #print(field + value)
        obj_to_call, data = self.common(model_str)
        print(data)
        data['fields'] = ['id','name','employee_ids','role_ids']
        if user_id:
            data['domain'] = [['id','=',user_id]]
        if acc_no:
            data['domain'] = [['acc_no','=',acc_no]]
        #print(data)

        if run:
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data),run=True)
        else:
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data))


    @rest_error()
    @http.route(['/app/marketer/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False)
    def query_read_app_marketer(self, model_str,field=False,value=False,employee_id=False,acc_no=False,run=False):
        #print(field + value)
        obj_to_call, data = self.common(model_str)
        print(data)
        data['fields'] = ['id','book']
        if employee_id:
            data['domain'] = [['marketer_employee_id.id','=',employee_id]]
        if acc_no:
            data['domain'] = [['acc_no','=',acc_no]]
        #print(data)

        if run:
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data),run=True)
        else:
            return self.parse_result(getattr(obj_to_call, 'search_read')(**data))


    @rest_error()
    @http.route(['/customer/payment/<string:model_str>'],
                type='http', auth='none', methods=['GET'], csrf=False)
    def query_payment_read(self, model_str,field=False,value=False,payment_id=False,old_acc_no=False,acc_no=False):
        print(field + value)
        obj_to_call, data = self.common(model_str)
        # print(data)
        data['fields'] = ['name','partner_id','payment_date','amount']
        if old_acc_no:
            url = "http://74.208.145.137:8069/customer/find/res.partner?old_acc_no=%s" % (old_acc_no)
            r = requests.get(url, auth=('ossyogbo@yahoo.com','EedcOsita@123'))
            get_user = r.json() 
            if get_user:
                print(get_user)
                data['domain'] = [['partner_id','=',get_user[0]['id']]]
        if acc_no:
            get_user = self.env['res.partner'].search([('acc_no','=',acc_no)])
            if get_user:
                data['domain'] = [['partner_id','=',get_user.id]]
        if payment_id:
            data['domain'] = [['id','=',payment_id]]
        print(data)

        return self.parse_result(getattr(obj_to_call, 'search_read')(**data))

    @rest_error()
    @http.route(['/customer/payment/post/<string:model_str>'],
                type='http', auth='none', methods=['POST'], csrf=False)
    def create(self, model_str):
        obj_to_call, data = self.common(model_str)
        return self.parse_result(getattr(obj_to_call, 'create')(data))


    # @rest_error()
    # @http.route(['/rest/<string:model_str>'],
    #             type='http', auth='none', methods=['GET'], csrf=False)
    # def search_read(self, model_str):
    #     obj_to_call, data = self.common(model_str)
    #     return self.parse_result(getattr(obj_to_call, 'search_read')(**data))

    @rest_error()
    @http.route(['/rest/<string:model_str>/<string:res_ids>'],
                type='http', auth='none', methods=['GET'], csrf=False)
    def read(self, model_str, res_ids=False):
        obj_to_call, data = self.common(model_str, res_ids)
        return self.parse_result(getattr(obj_to_call, 'read')(**data))

    @rest_error()
    @http.route(['/rest/<string:model_str>'],
                type='http', auth='none', methods=['POST'], csrf=False)
    def create(self, model_str):
        obj_to_call, data = self.common(model_str)


        if model_str == 'account.payment':

        #SET DEFAULT PAYMENT PAGES
            data['payment_method_id'] = 1
            data['journal_id'] = 9
            data['payment_type'] = 'inbound'

            url = "http://74.208.145.137:8069/customer/find/res.partner?old_acc_no=%s" % (data['partner_id'])
            r = requests.get(url, auth=('ossyogbo@yahoo.com','EedcOsita@123'))
            get_user = r.json()
            if len(get_user) < 0:
                return self.parse_result({'error': 'Customer Not Found'})     
            data['partner_id'] =  get_user[0]['id']
            get_account = getattr(obj_to_call, 'create')(data)

            if get_account.id:
                obj = {'name': get_account.name, 'id': get_account.id, 'amount': get_account.amount, 'payment_date': get_account.payment_date}
            else:
                obj = get_account
        else:
            obj = getattr(obj_to_call, 'create')(data).id    
        return self.parse_result(obj)

    @rest_error()
    @http.route(['/rest/<string:model_str>/<string:res_ids>'],
                type='http', auth='none', methods=['PUT'], csrf=False,cors="*")
    def write(self, model_str, res_ids=False):
        obj_to_call, data = self.common(model_str, res_ids,use_data=True)
        print(data)
        return self.parse_result(getattr(obj_to_call, 'write')(data))

    @rest_error()
    @http.route(['/rest/<string:model_str>/<string:res_ids>'],
                type='http', auth='none', methods=['DELETE'], csrf=False)
    def delete(self, model_str, res_ids=False):
        obj_to_call, data = self.common(model_str, res_ids)
        return self.parse_result(getattr(obj_to_call, 'unlink')(**data))

    @json_rest_error()
    @http.route('/web/json/<string:model_str>', type='json', csrf=False,cors="*", auth="none")
    def update_order_webhook(self,model_str,res_ids=False, **kwargs):
        if model_str != 'map.upfront':
            obj_to_call = self.jsoncommon(model_str, res_ids)
            model = request.env[model_str]
        obj = {}
        # model = request.env[model_str]
        data = request.params
        if request.env.uid == False:
            # Response.status = '401 Unauthorized login'
            return {'error':'User Login Failed'}
        # print(data)
        # print(model_str)
        if model_str == 'map.upfront':
            user_data = {}
            user_data['domain'] = [['acc_no','=',data['acc_no']]]
            user_data['fields'] = ['id']
            data['mc_date'] = date.today().strftime('%Y-%m-%d')
            data['mc_customer'] = True
            special_call = self.jsoncommon('res.partner', res_ids)
            # special_call = request.env['res.partner']
            get_user = getattr(special_call, 'search_read')(**user_data)
            # print(data['image'])
            if len(get_user) <= 0:
                return self.parse_result({'error': 'Customer Not Found'},run=True)
            else:
                # loaded = get_user.write(data)[0]
                data['id'] = get_user[0]['id']
                # loaded = getattr(special_call, 'write')(data)
                connection = psycopg2.connect(user = 'postgres',password = 'EedcOsita@123',host = '74.208.145.137',port = '5432',database = 'EEDCLIVE')
                cr = connection.cursor()
                cr.execute("update res_partner set mc_duration = %s, mc_amount = %s where id = %s" % (data['mc_duration'],data['mc_amount'],data['id']))
                connection.commit()
                return self.parse_result({'message': 'Update was successful'},run=True)

        elif model_str == 'account.payment':

        #SET DEFAULT PAYMENT PAGES
            data['payment_method_id'] = 1
            data['journal_id'] = 9
            data['payment_type'] = 'inbound'
            data['partner_type'] = 'customer'
            arrears = 0

            # url = "http://74.208.145.137:8069/customer/find/res.partner?old_acc_no=%s" % (data['partner_id'])
            # r = requests.get(url, auth=('ossyogbo@yahoo.com','EedcOsita@123'))
            # get_user = r.json()
            user_data = {}
            if(len(str(data['partner_id'])) > 7):
                user_data['domain'] = [['old_acc_no','=',data['partner_id']]]
            else:
                user_data['domain'] = [['acc_no','=',data['partner_id']]]
            user_data['fields'] = ['id','credit']
            special_call = request.env['res.partner']
            get_user = getattr(special_call, 'search_read')(**user_data)
            # print(data['image'])
            if len(get_user) <= 0:
                return self.parse_result({'error': 'Customer Not Found'})     
            data['partner_id'] =  get_user[0]['id']
            arrears = get_user[0]['credit']

            #Track Duplicate Payments
            if data['trans_ref'] != '':
                payment_data = {}
                    
                payment_data['domain'] = [['trans_ref','=',data['trans_ref']],['amount','=',data['amount']],['partner_id','=',data['partner_id']]]
                payment_data['fields'] = ['id','name','amount','partner_id','payment_date']
                special_call = request.env['account.payment']
                get_payments = getattr(special_call, 'search_read')(**payment_data)
                if len(get_payments) > 0:
                    return {'name': get_payments[0]['name'], 'id': get_payments[0]['id'], 'amount': get_payments[0]['amount'],'arrears': (arrears - data['amount']), 'payment_date': get_payments[0]['payment_date']}
            #End Track
            get_account = getattr(obj_to_call, 'create')(data)
            if get_account.id:
                obj = {'name': get_account.name, 'id': get_account.id, 'amount': get_account.amount, 'arrears': (arrears - get_account.amount), 'payment_date': get_account.payment_date}
            else:
                obj = get_account
        elif model_str == "account.invoice":
            inv_obj = request.env['account.invoice']
            inv_line_obj = request.env['account.invoice.line']
            result = []
            print(data)
            customer = request.env['feeder.customer.details'].search([('id','=',data['bill_id'])],limit=1)
            # search_data = {'domain':[['bill_id','=',self.id],['partner_id','=',customer.id]],'fields':'id'}
            is_entered = inv_obj.search([('bill_id','=',customer.reading_id.id),('partner_id','=',customer.customer_ids.id)]);

            print(len(is_entered))
        # return
            journal_id = 2
            inv_data = {
                    'name': customer.customer_ids.name,
                    'reference': customer.customer_ids.name,
                    'account_id': customer.customer_ids.property_account_receivable_id.id,
                    'partner_id': customer.customer_ids.id,
                    'currency_id': 3,
                    'journal_id': journal_id,
                    'origin': customer.reading_id.name.name,
                    'bill_id': customer.reading_id.id,
                    'reference_type': 'bill',
                    'company_id': 1,
                    'amount_tax': (customer.rate * 0.05),
                    }
                    
            inv_id = {}
            if len(is_entered) == 0:
                        
                try:
                    inv_id = inv_obj.create(inv_data)
                    inv_line_data = {
                            'name': "Electricity Bill",
                            'account_id': customer.user_class.product_id.property_account_income_id.id,
                            'price_unit': customer.rate,
                            'product_id': customer.user_class.product_id.id,
                            'consumption': customer.e_consumed,
                            'invoice_id': inv_id.id,
                            'quantity':1
                                }
                    inv_line_obj.create(inv_line_data)

                       
                except Exception as e:
                    print(e)                            
            else:
                update = inv_line_obj.search([('invoice_id','=',is_entered.id)])
                vals = {
                        'price_unit': customer.rate
                        }
                update.write(vals)

            
            print("Invoiced")
            customer.write({'bill_stage':'invoiced'})
            return {"Message": "Success"}
        elif model_str == "new.connection":
            data_create = {}
            print(data)
            #Read data
            # {"formid":"","juice":"","meter":"","bill_type":"postpaid/prepaid","tariff":"R2S"}
            #Create Customer
            allow_meter = False
            locid = ""
            juice_no = "None"
            meter_assigned = "None"
            odoo_acc_no = "None"
            if type(data['juice']) == type({}):
                allow_meter = True
            cursor = request.env.cr
            cursor.execute("select d.id as district,'%s' as metering_type,nc.id as new_connect,class.id as customer_class,%s as allow_meter,False as bill_status, nc.app_three_feeder as feeder_id,nc.app_three_transformer as transformer_id,concat(nc.a_surname,' ',nc.a_other_name) as display_name,concat(nc.a_surname,' ',nc.a_other_name) as name,nc.a_lga as city,d.state as state_id from new_connection nc left join res_district d on d.name = UPPER(concat(nc.district,' ','DISTRICT')) left join customer_class class on class.name = '%s' where nc.app_no = '%s'" % (data['metering_type'],allow_meter,data['tariff'],data['formid'])) 

            records = cursor.dictfetchall()
            if len(records) > 0:
                data_create = records[0]
                print("Data Create:",data_create)         
            #Check To Create Juice
            #{"name":name,"address":address,"city":city,"state":state,"phone":phone}
                if type(data['juice']) == type({}):
                    try:
                        url = "http://74.208.145.137:5000/juice/create"

                        user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36'
                        headers = {'Content-Type': 'application/json','User-Agent': user_agent}
                        details = {"name":data['juice']['name'],"address": data['juice']['address'],"city": data['juice']['city'],"state": data['juice']['state'].capitalize(),"phone":data['juice']['phone']}
                        print(details)
                        res = requests.post(url,json=details,headers=headers)
                        print(res.text)
                        datas = json.loads(res.text)			
                        # print(data)

                        data_create['mc_amount'] = data['juice']['mc_amount']
                        # data_create['mc_date'] = data['juice']['mc_date']
                        locid = datas['locid']
                        juice_no = datas['juice_acc_no']
                        data_create.update(datas)
                    except Exception as e:
                        print(e)
            #Check To assign Meter
            #{"disconnect": "Yes/No", "billing": "prepaid/postpaid", "sgc": "", "factor": "", "ststi": "", "phases": "", "com": "", "stskrn": "", "locid":"", "tariff": "", "units": "", "serialnumbers": ""}
                if type(data['meter']) == type({}):
                    try:
                        url = "http://74.208.145.137:5000/meter/create"
                        details = {"locid":locid,"serialnumbers": data['meter']['serialnumbers'],"com": data['meter']['com'],"units": data['meter']['units'],"tariff":data['meter']['tariff'],"sgc":data['meter']['sgc'], "ststi": data['meter']['ststi'],"stskrn":data['meter']['stskrn'],"factor":data['meter']['factor'],"phases":data['meter']['phases'],"disconnect":data['meter']['disconnect'],"billing":"PrePaid"}
                        print(details)

                        user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36'
                        headers = {'Content-Type': 'application/json','User-Agent': user_agent}
                        res = requests.post(url,json=details,headers=headers)
                        print(res.text)
                        datas = json.loads(res.text)
                        # run = self.env['res.partner'].search([('id','=',self.id)])
                        # print(data)
                        data_create.update(datas)                        
                    except Exception as e:
                        print(e)
                todelete = []
                for key,item in data_create.items():
                    if data_create[key] == None and key != 'allow_meter': 
                        todelete.append(key)
                for delete in todelete:
                    data_create.pop(delete);
                if 'mc_amount' in data.keys():
                    data_create['mc_amount'] = data['mc_amount']
                    data_create['mc_status'] = True
                    data_create['allow_meter'] = True
                print(data_create)
                customer = request.env['res.partner']
                get_account = getattr(customer, 'create')(data_create)
                obj = {'juice_no':juice_no,'odoo_acc_no':get_account.acc_no,'meter_assigned':meter_assigned}
                print(obj)
                # nc_obj = request.env['new.connection']
                # update_cont = getattr(nc_obj,'write')({'acc_number':get_account.acc_no}) 
                # get_account.write({'new_connect':update_cont.id})

        else:
            if model_str == "feeder.customer.details":
                data['e_month'] = 9
                data['e_year'] = 2019

                consumed_data = {}
                consumed_data['domain'] = [['e_month','=',data['e_month']],['e_year','=',data['e_year']],['customer_acc_no','=',data['customer_acc_no']]]
                consumed_data['fields'] = ['id']
                special_call = request.env['feeder.customer.details']
                datas = getattr(special_call, 'search_read')(**consumed_data)
                if len(datas) > 0:
                    return {"Success": "Record Already Exists"}
            
                if data['image'] == '' or data['current_read'] == '' or data['customer_acc_no'] == '':
                    return {"error": "Empty Fields Must be filled"}     
                if data['previous_read'] > data['current_read']:
                    return {"error": "Current read must be greater than"}   
                data['e_consumed'] = data['current_read'] - data['previous_read']
                data['type'] = 'Metered'
            obj = {"ID": getattr(obj_to_call, 'create')(data).id} 
            obj = {"Success": "Record was successfully entered"} 

        # print(request.params)
        return obj


    @rest_error()
    @http.route(['/rest/<string:model_str>/<string:method_str>',
                 '/rest/<string:model_str>/<string:method_str>/<string:res_ids>'],
                type='http', auth='none', methods=['POST'], csrf=False)
    def universal(self, model_str, res_ids=False, method_str=False):
        obj_to_call, data = self.common(model_str, res_ids)
        return self.parse_result(getattr(obj_to_call, method_str)(**data))
