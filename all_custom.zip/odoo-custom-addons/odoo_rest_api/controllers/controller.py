from odoo import http, _, fields
from datetime import date
from odoo.http import request
from odoo.http import Response
from functools import wraps
import requests
import json
import base64
import psycopg2
import sys


class rest_error:
    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                response = request.make_response(
                    json.dumps({"error": str(e)}),
                    headers=[("content-type", "application/json")],
                )
                response.status_code = 200
                return response

        return wrapper


class json_rest_error:
    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                response = {"error": str(e)}
                print("Came TO ERROR ZONE")
                # Response.status = "400 BAD Response"
                return response

        return wrapper


class Main(http.Controller):
    @staticmethod
    def login(model_str, res_ids=False, params=False, get=False):
        data = dict()
        data_bytes = request.httprequest.stream.read()

        if data_bytes:
            data = data_bytes.decode("utf-8")
            json_acceptable_string = data.replace("'", '"')
            data = json.loads(json_acceptable_string)

            if "context" in data:
                request.context = dict(data["context"])
                data.pop("context")
        jdata = request.httprequest.environ["HTTP_AUTHORIZATION"].split(" ")[1]
        user, password = base64.b64decode(jdata).decode("utf-8", "ignore").split(":")
        request.env.uid = request.session.authenticate(
            request.session.db, user, password
        )
        data = json.loads('{"user_id":' + str(request.env.uid) + "}")
        model = request.env[model_str]
        obj_to_call = model
        return obj_to_call, data

    @staticmethod
    def common(model_str, res_ids=False, params=False, login=False, use_data=False):
        data = dict()
        data_bytes = request.httprequest.stream.read()

        if use_data:
            data = data_bytes.decode("utf-8")
            json_acceptable_string = data.replace("'", '"')
            data = json.loads(json_acceptable_string)

            if "context" in data:
                request.context = dict(data["context"])
                data.pop("context")

        # jdata = request.httprequest.environ["HTTP_AUTHORIZATION"].split(" ")[1]
        jdata = request.httprequest.headers["Authorization"].split(" ")[1]
        user, password = base64.b64decode(jdata).decode("utf-8", "ignore").split(":")
        request.env.uid = request.session.authenticate(
            request.session.db, user, password
        )
        model = request.env[model_str]

        print("user_id: ", request.env.uid)

        obj_to_call = model
        if login:
            if str(request.env.uid) != "False":
                user_data = {}
                user_data["domain"] = [["id", "=", str(request.env.uid)]]
                user_data["fields"] = ["id", "name", "employee_ids"]

                get_user = getattr(obj_to_call, "search_read")(**user_data)
                print(get_user)
                if len(get_user) > 0:
                    data = {
                        "user_id": str(request.env.uid),
                        "name": get_user[0]["name"],
                        "employee_ids": get_user[0]["employee_ids"],
                        "role_ids": "",
                    }
                else:
                    data = {"user_id": "False"}
            else:
                data = {"user_id": str(request.env.uid)}
            return obj_to_call, data

        if res_ids:
            res_ids = "[" + res_ids + "]"
            obj_to_call = model.browse(json.loads(res_ids))
        return obj_to_call, data

    @staticmethod
    def jsoncommon(model_str, res_ids=False, params=False, login=False):
        # data = dict()
        # data_bytes = request.httprequest.stream.read()

        # if data_bytes:
        #     data = data_bytes.decode("utf-8")
        #     json_acceptable_string = data.replace("'", "\"")
        #     data = json.loads(json_acceptable_string)

        #     if 'context' in data:
        #         request.context = dict(data['context'])
        #         data.pop('context')
        print(request.httprequest.headers)
        jdata = request.httprequest.headers["Authorization"].split(" ")[1]
        user, password = base64.b64decode(jdata).decode("utf-8", "ignore").split(":")

        request.env.uid = request.session.authenticate(
            request.session.db, user, password
        )
        print("user_id: ", request.env.uid)

        model = request.env["res.partner"]
        obj_to_call = model

        if login:
            if str(request.env.uid) != "False":
                user_data = {}
                user_data["domain"] = [["id", "=", str(request.env.uid)]]
                user_data["fields"] = ["id", "name", "employee_ids"]
                get_user = getattr("res.partner", "search_read")(**user_data)

                # print(get_user)
                print(get_user)
                data = {
                    "user_id": str(request.env.uid),
                    "name": get_user[0]["name"],
                    "employee_ids": get_user[0]["employee_ids"],
                    "role_ids": "",
                }
            else:
                data = {"user_id": str(request.env.uid)}
            return obj_to_call

        # if res_ids:
        #     res_ids = '[' + res_ids + ']'
        #     obj_to_call = model.browse(json.loads(res_ids))
        return obj_to_call

    @staticmethod
    def parse_result(result, run=False):
        try:
            if run:
                return json.dumps(result)
            else:
                return request.make_response(
                    json.dumps(result), headers=[("content-type", "application/json")]
                )
        except:
            return request.make_response(str(result))

    # INVENTORY API
    @http.route(
        ["/api/product/create"],
        type="http",
        auth="none",
        methods=["GET"],
        csrf=False,
    )
    def create_product(self):
        # creates product from name, attributes, etc
        pass

    @http.route(
        ["/api/product/attributes"],
        type="http",
        auth="none",
        methods=["GET"],
        csrf=False,
    )
    def get_product_attributes(self):
        # returns attributes ids and values
        pass

    @http.route(
        ["/api/product/categories"],
        type="http",
        auth="none",
        methods=["GET"],
        csrf=False,
    )
    def get_product_categories(self):
        # returns categories id and name
        categories_model = request.env["product.category"].search([])

        response_categories = []
        for category in categories_model:
            category_id = category.id
            category_name = category.complete_name
            response_categories.append({"id": category_id, "category": category_name})

        print("\n\n", response_categories, "\n\n")

        return {"success": True, "categories": response_categories}
        # return "<h1>Test<\h1>"

    @http.route(
        ["/api/product/variants/"],
        type="http",
        auth="none",
        methods=["GET"],
        csrf=False,
    )
    def get_product_variants(self, product_tmpl_id):
        # returns variants for a tmpl for pass
        pass

    @http.route(
        ["/api/products/update_qty/"],
        type="http",
        auth="none",
        methods=["GET"],
        csrf=False,
    )
    def update_product_quantity(self, product_id):
        # returns variants for a tmpl for pass
        pass
