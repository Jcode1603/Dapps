{
    'name': 'Universal Rest API',
    'author': 'Grzegorz Krukar (grzegorzgk1@gmail.com)',
    'version': '1.0.0',
    'summary': 'Universal Rest API',
    'description': """Universal Rest API""",
    'images': ['static/images/banner.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
    'price': 25.00,
    'currency': 'EUR',
}

#### HISTORY ####

# VERSION - 1.0.0 [2018-02-12]
# First Version
