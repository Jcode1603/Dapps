# **SMARTPOWER REST API**

## **AUTHENTICATION**
Authentication is done with a base64 encoded string of username and password. 

**Setup**
1. Encode string of `username:password`
2. Add Authorization header to request
```
headers = {
    Authorization:  f"Basic {encoded_string}"
    }
```

## **ENDPOINTS**

- **Create Customer Record** 

    * POST: `/web/json/<model>`
    * Customers Model: res.partner
    * Required Fields: name, bill_status, allow_meter, tariff_rate, metering_type,district, customer_category

    **Post Data Format**
    ```
    {
    "name": "test_user",
    "bill_status": "INACTIVE",
    "allow_meter": "f",
    "tariff_rate": 50.5,
    "active": "t",
    "metering_type": "postpaid",
    "district": 53,
    "customer_category": "NON-MD"
    }
    ```

    **Successful Output**
    ```
   {
    "jsonrpc": "2.0",
    "id": null,
    "result": {
        "success": "Customer 1381645 with account number 1669452472 created successfully"
        }
    }
    ```

- **Update Customer Record**
    * POST: `/web/json/update/<model>`
    * Customers Model: res.partner
    * Required Fields: acc_no


    **Post Data Format**
    ```
    {
    "acc_no": 2341667166,
    "name": "test_boy",
    "bill_status": "INACTIVE",
    "allow_meter": "f",
    "tariff_rate": 53.5,
    "active": "t"
    }
    ```

    **Successful Output**
    ```
    {
    "jsonrpc": "2.0",
    "id": null,
    "result": {
        "success": "Customer 1381640 with account number 2341667166 updated successfully"
        }
    }
    ```


    




