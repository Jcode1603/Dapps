# -*- coding: utf-8 -*-
{
    'name': "Bagswarehouseng Product Extension",

    'summary': """
        Product Extension module.""",

    'description': """
        this module is designed to handle the extensions to the products 
    """,

    'author': "Steve Olise",
    "license": "AGPL-3",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': [
        'base',
        'product',
    ],

    'data': [
        'views/product_views.xml',
    ],
}