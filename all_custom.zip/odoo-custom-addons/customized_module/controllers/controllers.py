# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request,Response
import requests
import json
import odoo

class CustomizedModule(http.Controller):
    # @http.route('/customized_module/customized_module', auth='public')
    # def index(self, **kw):
    #     return "Hello, world"

    # @http.route('/customized_module/customized_module/objects', auth='public')
    # def list(self, **kw):
    #     return http.request.render('customized_module.listing', {
    #         'root': '/customized_module/customized_module',
    #         'objects': http.request.env['customized_module.customized_module'].search([]),
    #     })

    # @http.route('/customized_module/customized_module/objects/<model("customized_module.customized_module"):obj>', auth='public')
    # def object(self, obj, **kw):
    #     return http.request.render('customized_module.object', {
    #         'object': obj
    #     })

    @http.route("/api/login/", type="json", csrf=False, cors="*", auth="none")
    def login(self,res_ids=False, **kwargs):
        try:
        # print('I am params',request.params)
            if not (request.params.get('username') and request.params.get('password')):
                context = {
                "status": False,
                "message": "Username or Password Missing",
                }
                Response.status='400'
                return context
            request.env.uid = request.session.authenticate(request.session.db, request.params['username'], request.params['password'])
            print('I am res_id',request.env.uid)
            data = request.env['res.users'].search([('id','=',request.env.uid)])
            # print('I am data',data)
            # print('I am key',data[0].openapi_token)
            context = {
                "status": True,
                "message": "Login Successful",
                "data":{
                    "id": request.env.uid,
                    "api-token": data[0].openapi_token
                }
            }
        except odoo.exceptions.AccessDenied:
            context ={
                "status": False,
                "message": "Username or Password incorrect !!!!"
            }
            Response.status='400'


        return context
        
        
