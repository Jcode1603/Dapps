from odoo import fields, models, api, _
from odoo.exceptions import ValidationError

class DriverCommission(models.Model):
    _name = 'driver.commission'

    @api.model
    def create(self, vals):
        res = super(DriverCommission, self).create(vals)
        driver_count = 0
        for driver in res.driver_ids:
            driver_exists = self.env['driver.commission'].sudo().search([('driver_ids', 'in', driver.id)])
            if len(driver_exists) > 1:
                driver_count += 1
        if driver_count > 0:
            raise ValidationError("Commission for this driver(s) already exists")
        return res
    
    # @api.depends("commission_type", "percentage", "price", "points")
    # def _compute_reward(self):
    #     for rec in self:
    #         if rec.commission_type == "fixed":
    #             rec.reward = rec.price
    #         elif rec.commission_type == "points":
    #             rec.reward = rec.points
    #         elif rec.commission_type == "percentage":
    #             rec.reward 

    driver_ids = fields.Many2many('res.partner', string="Dispatch drivers")
    commission_type = fields.Selection([('fixed', 'Fixed price per order'), ('percentage', 'Order price percentage'), ('points', 'Points per order')], string="Commission Type", default="points")
    percentage = fields.Float(string="Percentage")
    price = fields.Float(string="Fixed Price")
    points = fields.Float(string="Points")
    reward = fields.Float(string="Computed reward value")


class DriverPoints(models.Model):
    _name = 'driver.points'

    delivery_ref = fields.Many2one('picking.order', string="Order")
    date = fields.Datetime(default=fields.Datetime.now(), string="Date")
    partner = fields.Many2one('res.partner')
    reward = fields.Float(string="Commission")
    commission_type = fields.Selection([('fixed', 'Fixed price per order'), ('percentage', 'Order price percentage'), ('points', 'Points per order')], string="Type", default="points")

class PickingOrder(models.Model):
    _inherit = "picking.order"

    payment_terms = fields.Many2one('account.payment.term', string="Payment terms", related="sale_order.payment_term_id", store=True)

    def give_commission(self):
        commission = self.env["driver.commission"].sudo().search([('driver_ids', 'in', self.delivery_boy.id)], limit=1)
        if commission:
            reward = 0.0
            if commission.commission_type == "fixed":
                reward += commission.price
            elif commission.commission_type == "points":
                reward += commission.points
            elif commission.commission_type == "percentage":
                if commission.percentage > 0.0:
                    reward += (commission.percentage/100) * self.sale_order.amount_total
            points = self.env['driver.points'].sudo().create({'delivery_ref': self.id, 'partner': self.delivery_boy.id, 'reward':reward, 'commission_type': commission.commission_type})

        else:
            raise ValidationError("please configure commissions for this driver")
        
    def pick_delivery(self):
        super(PickingOrder, self).pick_delivery()
        self.picking.delivery_state = 'picked'
        
        


class ResPartner(models.Model):
    _inherit = "res.partner"

    @api.depends('name', 'mobile')
    def name_get(self):
        res = super(ResPartner, self).name_get()
        result = []
        for account in self:
            result.append((account.id, '%s %s' % (res[0][1], account.mobile or '')))
        return result

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        if args is None:
            args = []
        domain = args + ['|', ('mobile', operator, name), ('name', operator, name)]
        return self._search(domain, limit=limit, access_rights_uid=name_get_uid)
    
    @api.constrains('mobile')
    def constrain_mobile(self):
        for rec in self:
            exist_no = self.search_count([('mobile', '=', rec.mobile)])
            print("exist no ",exist_no)
            if exist_no > 1:
                raise ValidationError("User already exists with this phone number")
            
    def open_partner_ledger(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Partner Ledger'),
            'view_mode': 'tree,pivot,graph',
            'res_model': 'account.move.line',
            'domain': [('partner_id', '=', self.id),('display_type', 'not in', ('line_section', 'line_note'))],
            'context': {'journal_type':'general', 'search_default_group_by_partner': 1, 'search_default_posted':1, 'search_default_payable':1, 'search_default_receivable':1, 'search_default_unreconciled':1},
            # 'view_id': self.env.ref('account.view_move_line_tree_grouped_partner').id,
        }

    driver_points = fields.One2many("driver.points", "partner")
    email = fields.Char(tracking=1)



