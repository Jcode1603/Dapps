from odoo import http, _
from odoo.http import request
from odoo.exceptions import UserError
import json
from odoo.addons.web.controllers.main import Home
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.addons.website_sale_delivery.controllers.main import WebsiteSaleDelivery

# class Home(Home):

#     @http.route()
#     def index(self, *args, **kw):
#         products = request.env['product.template'].sudo().search([], order="")

class CustomerPortalZone(CustomerPortal):

    MANDATORY_BILLING_FIELDS = ["name", "phone", "email", "street", "city", "country_id", "zone_configuration_id"]

class LynviWebsite(WebsiteSaleDelivery):

    @http.route(['/shop/carrier_rate_shipment'], type='json', auth='public', methods=['POST'], website=True)
    def cart_carrier_rate_shipment(self, carrier_id, **kw):
        order = request.website.sale_get_order(force_create=True)

        if not int(carrier_id) in order._get_delivery_methods().ids:
            raise UserError(_('It seems that a delivery method is not compatible with your address. Please refresh the page and try again.'))

        Monetary = request.env['ir.qweb.field.monetary']

        res = {'carrier_id': carrier_id}
        carrier = request.env['delivery.carrier'].sudo().browse(int(carrier_id))
        rate = carrier.rate_shipment(order)
        if rate.get('success'):
            tax_ids = carrier.product_id.taxes_id.filtered(lambda t: t.company_id == order.company_id)
            if tax_ids:
                fpos = order.fiscal_position_id
                tax_ids = fpos.map_tax(tax_ids)
                taxes = tax_ids.compute_all(
                    rate['price'],
                    currency=order.currency_id,
                    quantity=1.0,
                    product=carrier.product_id,
                    partner=order.partner_shipping_id,
                )
                if request.env.user.has_group('account.group_show_line_subtotals_tax_excluded'):
                    rate['price'] = taxes['total_excluded']
                else:
                    rate['price'] = taxes['total_included']

            res['status'] = True
            res['new_amount_delivery'] = Monetary.value_to_html(order.amount_delivery if order.amount_delivery else rate['price'], {'display_currency': order.currency_id})
            res['is_free_delivery'] = not bool(rate['price'])
            res['error_message'] = rate['warning_message']
        else:
            res['status'] = False
            res['new_amount_delivery'] = Monetary.value_to_html(0.0, {'display_currency': order.currency_id})
            res['error_message'] = rate['error_message']
        return res
    

    @http.route('/lynvi/form_submit/<string:model_name>', type='http', auth='public', methods=['POST'], website=True)
    def conversation_info(self, model_name, **kwargs):
        email = kwargs.get('email_from')
        phone = kwargs.get('phone')
        trip_style = kwargs.get('dmform-6')
        type_of_travel = kwargs.get('dmform-8')
        message = kwargs.get('description')
        countries_in_offer = kwargs.get('countries_in_offer')
        no_of_adults_traveling = kwargs.get('no_of_adults_traveling')
        no_of_children = kwargs.get('no_of_children')
        check_in_date = kwargs.get('check_in_date')
        lodging_type = kwargs.get('What type of lodging do you want?')
        name = kwargs.get('name')
        per_person_budget = kwargs.get('per_person_budget')
        duration = kwargs.get('duration')
        must_haves = kwargs.get('must_have')
        exclude = kwargs.get('exclude')
        country_of_residence = kwargs.get('country')
        state = kwargs.get('state')
        city = kwargs.get('city')
        other_services = kwargs.get('Other Services Needed')
        include_international_flight = kwargs.get('Include_international_flights')
        try:
            # project = request.env['project.project'].sudo().search([('name', '=', 'Tour & Travel Forms')], limit=1)
            contact = request.env['res.partner'].sudo().create({'name': name, 'email': email, 'phone': phone})
            
            task = request.env['project.project'].sudo().create({'type_of_travel': type_of_travel, 'trip_style': trip_style, 'partner_id': contact.id,
                                                            'Number_of_adults': no_of_adults_traveling, 'Number_of_children': no_of_children, 
                                                            'countries_to_visit': countries_in_offer, 'message': message, 
                                                            'check_in_date': check_in_date, 'type_of_lodging': lodging_type, 
                                                            'per_person_budget': per_person_budget, 'duration': duration, 
                                                            'must_haves': must_haves, 'exclude': exclude, 'country_of_residence': country_of_residence, 
                                                            'state': state, 'city': city, 'name': name, 'other_services': other_services, 
                                                            'include_international_flight': include_international_flight})
            
            return json.dumps({'id': task.id})
        except:
            return json.dumps({
                'error': _("The form's data is incomplete, please fill form again")
            })

        