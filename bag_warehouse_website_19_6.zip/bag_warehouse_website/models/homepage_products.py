from odoo import models, fields, api, tools, _
from datetime import timedelta
from odoo.exceptions import UserError
from odoo.tools.misc import clean_context
import datetime

class HomeProducts(models.Model):
    _inherit = 'product.template'

    homepage_product = fields.Selection([('new', 'New'), ('featured', 'Featured'), ('top', 'Top Sellers'), ('deal', 'Deal of the day')], string="Homepage product listing")
    deal_expiry_date = fields.Datetime(string="Deal expiry date", required_if_homepage_product='deal')
    deal_discount_percentage = fields.Float(string="Deal discount %", required_if_homepage_product='deal')
    replenish_date = fields.Datetime(string="Replenish Date")
    # product_weight = fields.Float(string="Weight")
    weight = fields.Float(
        'Weight', compute='_compute_weight', digits='Stock Weight',
        inverse='_set_weight', store=True, required=True)
    default_code = fields.Char(
        'SKU', compute='_compute_default_code',
        inverse='_set_default_code', store=True)
    
    @api.onchange('deal_discount_percentage')
    def discount_price_onchange(self):
        if self.deal_discount_percentage != 0:
            discount_price = (self.deal_discount_percentage/100) * self.list_price
            self.list_price = self.list_price - discount_price

    @api.onchange('weight')
    def add_weight_to_description(self):
        if self.weight > 0:
            self.description_sale += ('\nWeight: ' + str(self.weight) + 'kg') 

class Product(models.Model):
    _inherit = 'product.product'

    default_code = fields.Char('SKU', index=True)


class SaleOrder(models.Model):
    _inherit = 'product.product'

    user_id = fields.Many2one(
        'res.users', string='In-Store Attendant', index=True, tracking=2, default=lambda self: self.env.user,
        domain=lambda self: "[('groups_id', '=', {}), ('share', '=', False), ('company_ids', '=', company_id)]".format(
            self.env.ref("sales_team.group_sale_salesman").id
        ),)
    
class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    sku = fields.Char(string="SKU", compute="_fix_sku")

    @api.depends('product_id')
    def _fix_sku(self):
    	for product in self:
    		product.sku = product.product_id.default_code
                
class ProductReplenishMod(models.TransientModel):
    _inherit = 'product.replenish'

    def launch_replenishment(self):
        uom_reference = self.product_id.uom_id
        self.quantity = self.product_uom_id._compute_quantity(self.quantity, uom_reference)
        try:
            self.env['procurement.group'].with_context(clean_context(self.env.context)).run([
                self.env['procurement.group'].Procurement(
                    self.product_id,
                    self.quantity,
                    uom_reference,
                    self.warehouse_id.lot_stock_id,  # Location
                    _("Manual Replenishment"),  # Name
                    _("Manual Replenishment"),  # Origin
                    self.warehouse_id.company_id,
                    self._prepare_run_values()  # Values
                )
            ])
            self.product_tmpl_id.replenish_date = self.date_planned
        except UserError as error:
            raise UserError(error)