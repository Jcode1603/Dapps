from odoo import models, fields, api, tools
from datetime import timedelta
import datetime

class HomeProducts(models.Model):
    _inherit = 'product.template'

    homepage_product = fields.Selection([('new', 'New'), ('featured', 'Featured'), ('top', 'Top Sellers'), ('deal', 'Deal of the day')], string="Homepage product listing")
    deal_expiry_date = fields.Datetime(string="Deal expiry date", required_if_homepage_product='deal')